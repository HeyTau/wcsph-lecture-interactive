import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const docs = path.join(root, 'docs');
const out = path.resolve(root, '../发布包');
fs.mkdirSync(out, { recursive: true });
const data = (file, mime) => `data:${mime};base64,${fs.readFileSync(file).toString('base64')}`;
let html = fs.readFileSync(path.join(docs, 'index.html'), 'utf8');
let katex = fs.readFileSync(path.join(docs, 'vendor/katex/katex.min.css'), 'utf8');
katex = katex.replace(/url\(([^)]+)\)/g, (_, file) => {
  const clean = file.replace(/["']/g, '');
  const ext = path.extname(clean).slice(1);
  return `url("${data(path.join(docs, 'vendor/katex', clean), `font/${ext}`)}")`;
});
const styles = fs.readFileSync(path.join(docs, 'styles.css'), 'utf8').replace("@import url('./explorer.css');", fs.readFileSync(path.join(docs, 'explorer.css'), 'utf8'));
html = html.replace('<link rel="stylesheet" href="./vendor/katex/katex.min.css">', `<style>${katex}</style>`)
  .replace('<link rel="stylesheet" href="./styles.css">', `<style>${styles}</style>`);
const models = fs.readFileSync(path.join(docs, 'solver.mjs'), 'utf8').replace(/^export /gm, '') + '\n' + fs.readFileSync(path.join(docs, 'explorer.js'),'utf8').replace(/^import .*?;\s*/m,'');
const interactions = fs.readFileSync(path.join(docs, 'interactions.js'), 'utf8').replace(/^import .*?;\s*/m, '');
html = html.replace('<script type="module" src="./interactions.js"></script>', '')
  .replace('</body>', `<script>\n${models}\n${interactions}\n</script>\n</body>`);
html = html.replace(/(href|src)="(\.\/assets\/[^"]+)"/g, (_, attr, rel) => `${attr}="${data(path.resolve(docs, rel), rel.endsWith('.svg') ? 'image/svg+xml' : 'image/png')}"`)
  .replace('href="./lecture.md"', `href="${data(path.join(root, 'lecture.md'), 'text/markdown;charset=utf-8')}" download="WCSPH-lecture.md"`);
html = html.replace('download="WCSPH-lecture.md" download', 'download="WCSPH-lecture.md"');
if (/(?:href|src)="\.\//.test(html) || /@import/.test(html)) throw new Error('Standalone page still contains local dependencies');
fs.writeFileSync(path.join(out, 'index.html'), html);
fs.copyFileSync(path.join(root, 'PUBLISH.md'), path.join(out, 'README.md'));
console.log(`Standalone HTML ready: ${(Buffer.byteLength(html) / 1024 / 1024).toFixed(2)} MiB; all images, fonts, formulas and interaction code included.`);
