import assert from 'node:assert/strict';
import {fieldKernel,makeSamples,sampleVolumes,reconstructField,temperatureField,materialState} from '../src/field-models.mjs';
const close=(a,b,tolerance=1e-7)=>assert.ok(Math.abs(a-b)<tolerance,`${a} != ${b}`);
for(const h of [.025,.09,.18]){
 let total=0,dx=4*h/20000;for(let i=0;i<20000;i++)total+=fieldKernel(-2*h+(i+.5)*dx,h)*dx;close(total,1);
 close(fieldKernel(2*h,h),0);
}
for(const n of [7,15,31]){
 const points=makeSamples(n,'constant');points[Math.floor(n/2)].x+=.1/n;
 const volumes=sampleVolumes(points);assert.ok(volumes.every(v=>v>0));close(volumes.reduce((s,v)=>s+v,0),1);
 for(const h of [.025,.09,.18])for(let q=0;q<=100;q++){
   const x=q/100,raw=reconstructField(points,x,h),normal=reconstructField(points,x,h,true);
   close(raw.value,raw.partition);
   close(raw.terms.reduce((s,t)=>s+t.contribution,0),raw.value);
   if(normal.supported) {close(normal.value,1);close(normal.terms.reduce((s,t)=>s+t.contribution,0),1);}
   else assert.equal(normal.value,null);
   const periodic=reconstructField(points,x+1,h,true);assert.equal(periodic.value===null,normal.value===null);if(normal.value!==null)close(periodic.value,normal.value);
 }
}
const sparse=reconstructField(makeSamples(7),0,.025,true);assert.equal(sparse.supported,false);assert.equal(sparse.value,null);
const dense=makeSamples(15),before=reconstructField(dense,.5,.09);dense[7].value+=.5;const after=reconstructField(dense,.5,.09);
close(after.value-before.value,.5*after.terms[7].weight);
const eps=1e-5;
for(const u of [-1.5,0,1,1.5])for(const c of [-1,0,1])for(const source of [-1,0,1])for(const time of [0,2,6]){
 const settings={u,c,source,time,x0:1.2},s=materialState(settings);
 const numerical=(temperatureField(1.2+u*(time+eps),time+eps,settings)-temperatureField(1.2+u*(time-eps),time-eps,settings))/(2*eps);
 const local=(temperatureField(s.x,time+eps,settings)-temperatureField(s.x,time-eps,settings))/(2*eps);
 close(s.total,numerical,1e-6);close(s.local,local,1e-6);close(s.total,s.local+s.advection);assert.ok(s.x>=0&&s.x<10);
}
const follow=materialState({u:1,c:1,source:0,x0:1.2,time:2});close(follow.total,0);close(follow.temperature,temperatureField(1.2,0));
assert.ok(Math.abs(follow.fixedLocal-follow.local)>.1,'Local term at the particle must not be conflated with the fixed-probe derivative');
const staticField=materialState({u:1,c:0,time:2});close(staticField.local,0);assert.ok(Math.abs(staticField.total)>1);
const stationary=materialState({u:0,c:0,source:1,time:2,x0:1.2});close(stationary.total,1);close(stationary.temperature,stationary.fixedTemperature);
console.log('PASS: periodic volumes, kernel normalization, partition/constant reproduction, no-neighbor gaps, contribution linearity and analytic material derivatives against central differences.');
