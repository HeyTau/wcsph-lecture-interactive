import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'docs');
const html = fs.readFileSync(path.join(output, 'index.html'), 'utf8');
const source = fs.readFileSync(path.join(root, 'lecture.md'), 'utf8').replace(/\r\n/g, '\n');
const report = JSON.parse(fs.readFileSync(path.join(root, 'build-report.json'), 'utf8'));
assert.equal(report.sourceSha256, createHash('sha256').update(source).digest('hex'), 'HTML must match the current source');
const expected = [...source.matchAll(/\\tag\{(\d+)\}/g)].map((m) => Number(m[1]));
assert.deepEqual(report.equationNumbers, expected, 'Preserve every numbered equation in order');
assert.equal(new Set(expected).size, expected.length, 'Equation numbers must be unique');
assert.equal(report.displayMath, (source.match(/^\$\$\s*$/gm) || []).length / 2);
assert.equal(report.images.length, (source.match(/^!\[/gm) || []).length);
assert.equal((html.match(/<annotation encoding="application\/x-tex">/g) || []).length, report.inlineMath + report.displayMath, 'Every formula must retain accessible math and TeX');
assert.ok(!html.includes('katex-error'), 'No failed formulas');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
assert.equal(new Set(ids).size, ids.length, 'HTML IDs must be unique');
for (const [, target] of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
  if (target.startsWith('#')) assert.ok(ids.includes(target.slice(1)), `Broken anchor: ${target}`);
  else if (!/^https?:|^mailto:/.test(target)) assert.ok(fs.existsSync(path.resolve(output, decodeURIComponent(target))), `Missing asset: ${target}`);
}
for (const src of report.images) {
  assert.ok(fs.readFileSync(path.resolve(root, src)).equals(fs.readFileSync(path.resolve(output, src))), `Image was changed: ${src}`);
}
const css = fs.readFileSync(path.join(output, 'vendor/katex/katex.min.css'), 'utf8');
for (const [, font] of css.matchAll(/url\(([^)]+)\)/g)) assert.ok(fs.existsSync(path.join(output, 'vendor/katex', font.replace(/["']/g, ''))), `Missing font: ${font}`);
assert.ok(!/https?:\/\/[^"']+\.(?:css|js)/.test(html), 'Do not depend on a remote CDN');
assert.equal((html.match(/data-lab="/g) || []).length, 3, 'All three interactive experiments must be embedded');
for (const file of ['labs.css', 'interactions.js', 'models.mjs']) assert.ok(fs.existsSync(path.join(output, file)), `Missing interactive asset: ${file}`);
console.log(`PASS: ${report.displayMath} numbered display formulas; ${report.inlineMath} inline formulas; ${report.images.length} original images; all links, math annotations and local fonts verified.`);
