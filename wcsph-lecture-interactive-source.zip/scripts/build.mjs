import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import MarkdownIt from 'markdown-it';
import katex from 'katex';
import { densityLab, eosLab, timestepLab } from '../src/labs.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'docs');
const source = fs.readFileSync(path.join(root, 'lecture.md'), 'utf8').replace(/\r\n/g, '\n');
const stats = { inlineMath: 0, displayMath: 0, equationNumbers: [], images: [], headings: [] };
const md = new MarkdownIt({ html: false, linkify: true, typographer: false });
const escape = md.utils.escapeHtml;

// Parse math before Markdown can interpret underscores, pipes or backslashes.
md.block.ruler.before('fence', 'math_block', (state, start, end, silent) => {
  const line = (n) => state.src.slice(state.bMarks[n] + state.tShift[n], state.eMarks[n]).trim();
  if (line(start) !== '$$') return false;
  let close = start + 1;
  while (close < end && line(close) !== '$$') close++;
  if (close === end) throw new Error(`Unclosed display formula at line ${start + 1}`);
  if (silent) return true;
  const token = state.push('math_block', 'div', 0);
  token.content = state.getLines(start + 1, close, state.blkIndent, false).trim();
  token.map = [start, close + 1];
  state.line = close + 1;
  return true;
}, { alt: ['paragraph', 'reference', 'blockquote', 'list'] });

md.inline.ruler.before('escape', 'math_inline', (state, silent) => {
  const start = state.pos;
  if (state.src[start] !== '$' || state.src[start + 1] === '$') return false;
  let close = start + 1;
  while (close < state.posMax) {
    if (state.src[close] === '$' && state.src[close - 1] !== '\\') break;
    close++;
  }
  if (close === state.posMax) throw new Error(`Unclosed inline formula: ${state.src.slice(start, start + 80)}`);
  if (!silent) {
    const token = state.push('math_inline', 'math', 0);
    token.content = state.src.slice(start + 1, close);
  }
  state.pos = close + 1;
  return true;
});

function renderMath(tex, displayMode) {
  return katex.renderToString(tex, {
    displayMode, throwOnError: true, strict: 'error', trust: false,
    output: 'htmlAndMathml', maxExpand: 1000,
  });
}
md.renderer.rules.math_inline = (tokens, i) => {
  stats.inlineMath++;
  return renderMath(tokens[i].content, false);
};
md.renderer.rules.math_block = (tokens, i) => {
  stats.displayMath++;
  const tex = tokens[i].content;
  const number = tex.match(/\\tag\{(\d+)\}/)?.[1];
  if (number) stats.equationNumbers.push(Number(number));
  const id = number ? ` id="eq-${number}"` : '';
  const label = number ? `公式 ${number}` : '数学公式';
  return `<div class="equation"${id} tabindex="0" role="region" aria-label="${label}">${renderMath(tex, true)}</div>\n`;
};
md.renderer.rules.table_open = () => '<div class="table-scroll" tabindex="0" role="region" aria-label="讲义表格"><table>\n';
md.renderer.rules.table_close = () => '</table></div>\n';
const imageRule = md.renderer.rules.image;
md.renderer.rules.image = (tokens, i, options, env, renderer) => {
  const token = tokens[i];
  const src = token.attrGet('src');
  if (!src?.startsWith('./assets/')) throw new Error(`Unexpected image location: ${src}`);
  const local = path.resolve(root, src);
  if (!local.startsWith(path.join(root, 'assets') + path.sep) || !fs.existsSync(local)) {
    throw new Error(`Missing or invalid image: ${src}`);
  }
  if (!stats.images.includes(src)) stats.images.push(src);
  token.attrSet('loading', 'lazy');
  token.attrSet('decoding', 'async');
  token.attrSet('src', src.replace(/\.png$/, '.svg'));
  const png = fs.readFileSync(local);
  if (png.subarray(1, 4).toString() === 'PNG') {
    token.attrSet('width', String(png.readUInt32BE(16)));
    token.attrSet('height', String(png.readUInt32BE(20)));
  }
  return `<a class="figure-link" href="${escape(src)}" target="_blank" rel="noopener" aria-label="打开原图：${escape(token.content)}">${imageRule(tokens, i, options, env, renderer)}</a>`;
};

const tokens = md.parse(source, {});
let section = 0;
let subsection = 0;
for (let i = 0; i < tokens.length; i++) {
  if (tokens[i].type !== 'heading_open') continue;
  const depth = Number(tokens[i].tag.slice(1));
  let id;
  if (depth === 1) id = 'lecture-title';
  else if (depth === 2) { section++; subsection = 0; id = `section-${section}`; }
  else { subsection++; id = `section-${section}-${subsection}`; }
  tokens[i].attrSet('id', id);
  if (depth > 1) stats.headings.push({ depth, id, title: tokens[i + 1].content });
}
let body = md.renderer.render(tokens, md.options, {});
const summaryId = stats.headings.find((h) => h.depth === 2 && /总结/.test(h.title))?.id;
const chapterCount = stats.headings.filter((h) => h.depth === 2).length;
body = body.replace('<h2 id="section-2">', densityLab + '<h2 id="section-2">')
  .replace('<h3 id="section-3-3">', eosLab + '<h3 id="section-3-3">')
  .replace(`<h2 id="${summaryId}">`, timestepLab + `<h2 id="${summaryId}">`)
  .replace(/(<h2[^>]*>)(\d+)\.\s*/g, '$1<span class="section-no">CHAPTER $2</span>')
  .replace('<h1 id="lecture-title">', '<p class="article-kicker">COMPUTATIONAL FLUID DYNAMICS / 01</p><h1 id="lecture-title">')
  .replace('</h1>', `</h1><div class="article-meta"><span>${chapterCount} 个章节</span><span>${stats.displayMath} 个公式</span><span>3 组交互实验</span></div>`);
// Use a separate renderer for navigation so content validation counts only the article.
const toc = stats.headings.filter((h) => h.depth === 2).map((h) =>
  `<li><a class="chapter-link" href="#${h.id}"><span class="chapter-no">${h.title.match(/^\d+/)?.[0].padStart(2, '0') || ''}</span><span>${escape(h.title.replace(/^\d+\.\s*/, ''))}</span></a></li>`).join('\n');
const title = tokens.find((t) => t.type === 'inline')?.content;
const html = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="从 SPH 粒子表示、控制方程到 Tait 状态方程、完整时间步和实现伪代码的 WCSPH 中文讲义。">
  <meta name="color-scheme" content="light">
  <title>${escape(title)}</title>
  <link rel="stylesheet" href="./vendor/katex/katex.min.css">
  <link rel="stylesheet" href="./styles.css">
  <script type="module" src="./interactions.js"></script>
</head>
<body>
  <a class="skip-link" href="#lecture-title">跳到正文</a>
  <div id="reading-progress" aria-hidden="true"></div>
  <header class="masthead"><a class="wordmark" href="#lecture-title">WCSPH <span>INTERACTIVE LECTURE</span></a><span class="edition">HEYTAU / VOL. 01</span><a class="source-link" href="./lecture.md" download>讲义原稿 ↗</a></header>
  <div class="reading-layout">
    <aside class="sidebar"><details open><summary>阅读目录 <span>CONTENTS</span></summary><nav aria-label="章节目录"><ol>${toc}</ol></nav></details><div class="sidebar-labs"><p>交互实验</p><a href="#lab-density">粒子与密度 <span>↗</span></a><a href="#lab-eos">Tait 状态方程 <span>↗</span></a><a href="#lab-timestep">时间步的限制 <span>↗</span></a></div><p class="sidebar-note">WCSPH / FLUID DYNAMICS<br>INTERACTIVE EDITION</p></aside>
    <main><article aria-labelledby="lecture-title">${body}</article><footer><span>HeyTau · WCSPH Lecture</span><a href="#lecture-title">返回顶部 ↑</a></footer></main>
  </div>
  <dialog id="figure-dialog" class="figure-dialog"><header><span id="figure-caption"></span><button id="figure-close" type="button" aria-label="关闭插图">关闭 ×</button></header><img id="figure-large" alt=""><a id="figure-download" download>下载原始 PNG ↗</a></dialog>
</body>
</html>\n`;

fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'index.html'), html);
fs.copyFileSync(path.join(root, 'src/styles.css'), path.join(output, 'styles.css'));
for (const file of ['labs.css', 'interactions.js', 'models.mjs']) fs.copyFileSync(path.join(root, 'src', file), path.join(output, file));
fs.copyFileSync(path.join(root, 'lecture.md'), path.join(output, 'lecture.md'));
fs.writeFileSync(path.join(output, '.nojekyll'), '');
for (const src of stats.images) {
  const target = path.resolve(output, src);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(path.resolve(root, src), target);
  const svg = src.replace(/\.png$/, '.svg');
  const vector = fs.readFileSync(path.resolve(root, svg), 'utf8')
    .replaceAll('#f7f7f4', '#ffffff').replaceAll('#173a63', '#203349')
    .replaceAll('#223247', '#262c33').replaceAll('#c9622b', '#b96b43').replaceAll('#187e79', '#237b73');
  fs.writeFileSync(path.resolve(output, svg), vector);
}
const vendor = path.join(output, 'vendor/katex');
fs.mkdirSync(vendor, { recursive: true });
fs.copyFileSync(path.join(root, 'node_modules/katex/dist/katex.min.css'), path.join(vendor, 'katex.min.css'));
fs.mkdirSync(path.join(vendor, 'fonts'), { recursive: true });
for (const font of fs.readdirSync(path.join(root, 'node_modules/katex/dist/fonts'))) {
  fs.copyFileSync(path.join(root, 'node_modules/katex/dist/fonts', font), path.join(vendor, 'fonts', font));
}
fs.copyFileSync(path.join(root, 'node_modules/katex/LICENSE'), path.join(vendor, 'LICENSE'));
const report = { sourceSha256: createHash('sha256').update(source).digest('hex'), ...stats };
fs.writeFileSync(path.join(root, 'build-report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(`Built docs/index.html: ${stats.displayMath} display formulas, ${stats.inlineMath} inline formulas, ${stats.images.length} original images.`);

