import assert from 'node:assert/strict';
import { cubicKernel1D, density1D, taitPressure, timeLimits } from '../src/models.mjs';
const close = (a, b, tolerance = 1e-8) => assert.ok(Math.abs(a - b) < tolerance, `${a} != ${b}`);
for (const h of [.2, .45, .7]) {
  const dx = 4 * h / 10000;
  let integral = 0;
  for (let i = 0; i < 10000; i++) integral += cubicKernel1D(-2 * h + (i + .5) * dx, h) * dx;
  close(integral, 1);
  close(cubicKernel1D(2 * h, h), 0);
  close(cubicKernel1D(.3 * h, h), cubicKernel1D(-.3 * h, h));
}
const positions = Array.from({length: 9}, (_, i) => (i - 4) * .2);
close(density1D(0, positions, .4), 1);
close(density1D(0, positions, .4, .4), 2 * density1D(0, positions, .4));
for (const cs of [10, 20, 80]) {
  close(taitPressure(1, cs), 0);
  close(taitPressure(1.01, cs, 1), 1000 * cs ** 2 * .01, 1e-7);
  close(taitPressure(1.03, cs * 2), 4 * taitPressure(1.03, cs), 1e-7);
  const eps = 1e-5;
  const slope = (taitPressure(1 + eps, cs) - taitPressure(1 - eps, cs)) / (2 * 1000 * eps);
  close(slope, cs * cs, .001);
}
const limits = timeLimits({h:.02, cs:20, velocity:2, nu:0});
close(limits[0].value, .25 * .02 / 22);
assert.equal(limits[2].value, Infinity);
const viscous = timeLimits({h:.005, cs:5, velocity:0, nu:.02});
assert.equal(Math.min(...viscous.map((v) => v.value)), viscous[2].value);
console.log('PASS: normalized kernel, self contribution, mass scaling, Tait limits, sound-speed scaling and inactive/limiting timestep cases.');
