import assert from 'node:assert/strict';
import {RHO0,MASS,DEFAULT_H,kernel2D,gradient2D,makeParticles,compute,contributions,advance} from '../src/solver.mjs';
const near=(a,b,eps=1e-7)=>assert.ok(Math.abs(a-b)<eps,`${a} != ${b}`);
for(const h of [.07,DEFAULT_H,.13]){
 let integral=0,dr=2*h/20000;for(let i=0;i<20000;i++){const r=(i+.5)*dr;integral+=2*Math.PI*r*kernel2D(r,h)*dr;}near(integral,1,1e-8);
 for(const q of [.1,.7,1,1.4,1.9]){const r=q*h,eps=1e-7;near(gradient2D(r,0,h)[0],(kernel2D(r+eps,h)-kernel2D(r-eps,h))/(2*eps),1e-4);}
 assert.deepEqual(gradient2D(0,0,h),[0,0]);near(kernel2D(2*h,h),0);
}
const config={h:DEFAULT_H,cs:20,gamma:7,nu:0};
const rest=makeParticles('rest'),uniform=compute(rest,config);
near(uniform.rho[60],RHO0);assert.ok(uniform.rho[0]<RHO0);
const compressed=makeParticles('compressed'),f=compute(compressed,config);
assert.ok(f.rho[63]>uniform.rho[63]);assert.ok(f.pressure[63]>0);
const terms=contributions(compressed,63,config.h);near(terms.reduce((s,t)=>s+t.value,0),f.rho[63]);assert.ok(terms.some(t=>t.id===63));
near(compute(compressed,{...config,cs:40}).pressure[63],4*f.pressure[63],1e-5);
near(compute(compressed,{...config,cs:40}).dt,.5*f.dt);
near(f.acceleration.reduce((s,a)=>s+a.x*MASS,0),0,1e-6);near(f.acceleration.reduce((s,a)=>s+a.y*MASS,0),0,1e-6);
let angular=0;compressed.forEach((p,i)=>angular+=MASS*(p.x*f.acceleration[i].y-p.y*f.acceleration[i].x));near(angular,0,1e-6);
const next=advance(compressed,config,f);near(next.particles[63].vx,compressed[63].vx+f.dt*f.acceleration[63].x);near(next.particles[63].x,compressed[63].x+f.dt*next.particles[63].vx);
let pp=compressed;for(let i=0;i<150;i++){pp=advance(pp,config).particles;}assert.ok(pp[63].x>compressed[63].x);
for(const scene of ['rest','compressed','disturbed'])for(const h of [.07,.13])for(const cs of [10,60]){
 let ps=makeParticles(scene),params={...config,h,cs,nu:.005};
 for(let i=0;i<250;i++){const ff=compute(ps,params);assert.ok(Number.isFinite(ff.dt)&&ff.dt>0);ps=advance(ps,params,ff).particles;}
 assert.ok(ps.every(p=>[p.x,p.y,p.vx,p.vy].every(Number.isFinite)&&p.x>=.025&&p.x<=.975&&p.y>=.025&&p.y<=.975));
}
const velocities=rest.map((p,i)=>({...p,vx:Math.sin(i),vy:Math.cos(i)}));
const inviscid=compute(velocities,config),viscous=compute(velocities,{...config,nu:.005});
let dissipation=0;velocities.forEach((p,i)=>{dissipation+=MASS*(p.vx*(viscous.acceleration[i].x-inviscid.acceleration[i].x)+p.vy*(viscous.acceleration[i].y-inviscid.acceleration[i].y));});
assert.ok(dissipation<0);near(viscous.acceleration.reduce((s,a)=>s+a.x*MASS,0),0,1e-6);
console.log('PASS: 2D kernel normalization/gradient, density sum, compression pressure, sound-speed coupling, momentum conservation, Euler update, 3000 boundary-parameter steps and dissipative viscosity.');
