import katex from 'katex';
import {makeParticles} from './solver.mjs';
const math=tex=>katex.renderToString(tex,{throwOnError:true,strict:'error',trust:false});
const control=(id,label,min,max,step,value,unit)=>`<label class="parameter" for="${id}"><span>${label}<output id="${id}-value">${value} ${unit}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></label>`;
const stages=[['particles','粒子位置','xᵢ','121 个粒子'],['kernel','邻域加权','Wᵢⱼ','支撑半径 2h'],['density','密度求和','ρᵢ','— kg/m³'],['pressure','压力反馈','pᵢ','— kPa'],['integrate','显式推进','xᵢⁿ⁺¹','— ms']];
export const formulas={
particles:String.raw`\mathbf{x}_i=(x_i,y_i),\quad m_i=\mathrm{const.}`,
kernel:String.raw`W_{ij}=W(\|\mathbf{x}_i-\mathbf{x}_j\|,h)`,
density:String.raw`\rho_i=\underbrace{m_iW(0,h)}_{\text{self}}+\sum_{j\ne i}m_jW_{ij}`,
pressure:String.raw`p_i=\max\!\left(0,\frac{\rho_0c_s^2}{\gamma}\left[\left(\frac{\rho_i}{\rho_0}\right)^\gamma-1\right]\right)`,
integrate:String.raw`\mathbf v_i^{n+1}=\mathbf v_i^n+\Delta t\,\mathbf a_i^n`};
export const explorer = `<section class="explorer" id="explorer" aria-labelledby="explorer-title">
<div class="explorer-intro"><div><p class="overline">AN INTERACTIVE EXPLANATION</p><h1 id="explorer-title">看见粒子如何产生压力<span class="title-dot">.</span></h1><p>拖动一个粒子，沿着计算链，追踪它引起的每一次变化。</p></div><a class="read-link" href="#lecture-title">阅读完整讲义 <span>↓</span></a></div>
<div class="experiment-toolbar"><div class="scene-options" role="group" aria-label="初始粒子排列"><span class="toolbar-label">初始状态</span><button data-scene="rest" type="button" aria-pressed="false">均匀分布</button><button data-scene="compressed" type="button" aria-pressed="true">轻微压缩</button><button data-scene="disturbed" type="button" aria-pressed="false">局部扰动</button></div><div class="transport"><span class="simulation-time" id="simulation-time">t = 0.00 ms</span><button class="play-button" id="play" type="button" aria-pressed="false">▶ 播放</button><button id="single-step" type="button" title="按当前安全时间步推进一次">步进 →</button><button id="reset" type="button" aria-label="重置当前场景">↺</button></div></div>
<div class="pipeline" role="group" aria-label="选择计算阶段">${stages.map(([id,label,symbol,value],i)=>`<button type="button" class="pipeline-stage" data-stage="${id}" aria-pressed="${id==='kernel'}"><span class="stage-label"><span>0${i+1}</span> ${label}</span><span class="stage-symbol">${symbol}</span><span class="stage-value" id="pipeline-${id}">${value}</span></button>`).join('')}</div>
<div class="explorer-workspace">
<div class="particle-panel"><div class="panel-top"><span id="view-label">粒子邻域</span><div class="color-key" id="color-key"><i></i><span>距离越近，贡献越大</span></div></div>
<div class="particle-stage"><svg id="particle-canvas" viewBox="0 0 660 510" aria-label="可拖动的二维 SPH 粒子场；也可用下方编号选中粒子，再用方向键移动" role="group"><g id="scene-grid"></g><g id="scene-trails"></g><g id="scene-support"></g><g id="scene-links"></g><g id="scene-particles">${makeParticles().map(p=>`<circle cx="${100+p.x*460}" cy="${25+(1-p.y)*460}" r="4" fill="#b8c9d1"/>`).join('')}</g><g id="scene-labels"></g></svg><div class="canvas-tip"><span class="drag-icon">↔</span> 拖动粒子 · 点击选中 · 方向键微调</div></div>
<div class="particle-status"><label for="selected-particle">追踪粒子 <span>i =</span> <input id="selected-particle" type="number" min="0" max="120" step="1" value="63" aria-label="追踪的粒子编号"></label><span id="particle-position">x = 0.716, y = 0.500 m</span><span id="neighbor-count">— 个邻居</span></div>
</div>
<div class="trace-panel" aria-labelledby="trace-title"><div class="trace-heading"><span class="trace-index" id="trace-index">02 / 05</span><a id="trace-reference" href="#section-1">讲义中的推导 ↗</a></div><h2 id="trace-title">每个邻居，贡献多少？</h2><p class="trace-description" id="trace-description">核函数把距离转成权重。支撑域以外的粒子不参与求和。</p>
<div class="trace-formula" id="trace-formula">${math(formulas.kernel)}</div>
<svg id="trace-chart" viewBox="0 0 440 185" role="img" aria-label="选中粒子的局部计算过程"></svg>
<div id="trace-result" class="trace-result"></div><div id="contribution-list" class="contribution-list" aria-label="邻居对密度的贡献"></div><p id="trace-insight" class="trace-insight"></p>
</div></div>
<div class="parameter-strip">
${control('param-h','平滑长度 h',70,130,.25,93.75,'mm')}
${control('param-cs','人工声速 cₛ',10,60,1,20,'m/s')}
${control('param-gamma','Tait 指数 γ',1,9,1,7,'')}
${control('param-nu','运动黏度 ν',0,5000,50,0,'mm²/s')}
</div>
<div class="explorer-bottom"><span id="experiment-status" role="status">已暂停 · 可自由探索</span><details><summary>模型与单位</summary><p>121 个等质量粒子；二维切片厚度为 1 m，密度用 kg/m³ 表示。采用二维 cubic spline 核（支撑半径 2h）、Tait 方程、负压截断及对称压力力；可选物理黏性。质量由初始均匀点阵的中心密度标定为 1000 kg/m³，此后保持不变。演示关闭重力与表面张力，采用半隐式 Euler 和自适应时间步；边缘邻居不完整，未作密度补偿。播放时每帧推进一步，以慢放观察压力反馈。</p></details></div>
<noscript><p>交互演示需要启用 JavaScript；下方讲义与公式仍可阅读。</p></noscript>
${Object.entries(formulas).map(([id,tex])=>`<template id="formula-${id}">${math(tex)}</template>`).join('')}
</section>`;
const jump=(id,stage,title,text)=>`<aside class="explore-callout" id="${id}"><div><span>动手验证</span><strong>${title}</strong><p>${text}</p></div><a href="#explorer" data-explore="${stage}">打开演示 ↗</a></aside>`;
export const densityLab=jump('lab-density','density','一项一项，看密度如何相加','选择一个粒子，查看每个邻居的核加权质量。');
export const eosLab=jump('lab-eos','pressure','同一粒子，从密度追到压力','拖动粒子改变密度，观察它在 Tait 曲线上的位置。');
export const timestepLab=jump('lab-timestep','integrate','用当前压力，真正推进一步','观察压力力如何改变速度和位置，再重新计算邻域。');
