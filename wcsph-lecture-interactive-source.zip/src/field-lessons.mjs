import katex from 'katex';
const math=tex=>katex.renderToString(tex,{throwOnError:true,strict:'error',trust:false});
function slider(id,label,min,max,step,value,unit=''){return `<label class="fl-control" for="${id}"><span>${label}<output id="${id}-value">${value} ${unit}</output></span><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></label>`;}
const reconstructionRaw=math(String.raw`\widehat A(x)=\sum_j\underbrace{A_j}_{\text{value}}\underbrace{V_j}_{\text{volume}}\underbrace{W(x-x_j,h)}_{\text{weight}}`);
const reconstructionNormalized=math(String.raw`\widehat A_N(x)=\frac{\sum_j A_jV_jW(x-x_j,h)}{\sum_j V_jW(x-x_j,h)}`);
export const reconstructionLesson=`<!--interactive-start--><section class="field-lab" id="lab-reconstruction" aria-labelledby="reconstruction-title">
<header class="fl-head"><div><p class="fl-eyebrow">FIELD LAB / 01</p><h3 id="reconstruction-title">有限个粒子，如何铺成连续场？</h3><p>每个采样点贡献一座平滑的“小山”。叠加它们，就能在没有粒子的位置估计场值。</p></div><button type="button" id="reconstruction-reset" class="fl-reset" aria-label="重置连续场实验">↺</button></header>
<div class="fl-toolbar"><label>参考场 <select id="reconstruction-shape"><option value="wave">周期起伏</option><option value="bump">局部峰值</option><option value="constant">常数场</option></select></label><div class="fl-segments" role="group" aria-label="显示的重建阶段"><button type="button" data-reconstruction-layer="samples" aria-pressed="false">① 采样点</button><button type="button" data-reconstruction-layer="kernels" aria-pressed="false">② 核贡献</button><button type="button" data-reconstruction-layer="sum" aria-pressed="true">③ 重建场</button></div></div>
<div class="fl-formula" id="reconstruction-formula">${reconstructionRaw}</div>
<svg class="fl-main-chart" id="reconstruction-chart" viewBox="0 0 820 330" role="group" aria-label="可拖动的粒子采样与核重建曲线"></svg>
<div class="fl-legend"><span class="fl-dashed">参考场</span><span class="fl-green">重建值</span><span class="fl-orange">选中粒子的贡献</span><span class="fl-tip">拖动采样点改变位置 / 场值；拖动底部游标选择查询位置</span></div>
<div class="fl-readouts"><div><span>查询位置 x</span><strong id="reconstruction-query">0.500</strong><small>m</small></div><div><span>重建值 Â(x)</span><strong id="reconstruction-value">—</strong><small>无量纲</small></div><div><span>参考值 A(x)</span><strong id="reconstruction-reference">—</strong><small>无量纲</small></div><div><span>权重之和 Σ VⱼW</span><strong id="reconstruction-partition">—</strong><small>应接近 1</small></div></div>
<div class="fl-contribution"><div class="fl-contribution-title"><label for="reconstruction-selected">查看粒子 j = <input id="reconstruction-selected" type="number" min="0" max="14" step="1" value="7" aria-label="查看贡献的粒子编号"></label><span id="reconstruction-term">Aⱼ × Vⱼ × W = —</span></div><div id="reconstruction-terms" class="fl-terms" aria-label="查询位置处的粒子贡献"></div></div>
<div class="fl-controls fl-four">
${slider('reconstruction-count','粒子数量',7,31,2,15)}
${slider('reconstruction-h','平滑长度 h',.025,.18,.005,.09,'m')}
${slider('reconstruction-probe','查询位置 x',0,1,.001,.5,'m')}
${slider('reconstruction-sample','选中粒子的场值',0,2.5,.01,1.15)}
</div>
<div class="fl-options"><label><input type="checkbox" id="reconstruction-normalized"> 权重归一化（Shepard）</label><button type="button" id="reconstruction-resample">重新采样参考场 ↺</button></div>
<p class="fl-insight" id="reconstruction-insight" role="status"></p>
<details class="fl-model"><summary>模型与操作说明</summary><p>一维长度 1 m 的周期区间；A 为无量纲标量，二维 / 三维 SPH 的 Vⱼ 在此对应一维区间长度。Vⱼ 取相邻采样点中点划分的区间长度，移动粒子后重算，且总和为 1 m。核为归一化一维 cubic spline，支撑半径 2h，使用周期距离。拖动粒子时它携带的场值由你指定，不会自动重新采样参考场；改变数量或点击重新采样会恢复采样值。可用方向键微调选中点，底部游标也可用方向键移动。归一化模式下没有邻居的位置不定义重建值。</p></details>
<template id="reconstruction-raw-template">${reconstructionRaw}</template><template id="reconstruction-normal-template">${reconstructionNormalized}</template>
<noscript><p>启用 JavaScript 后可探索采样与重建；正文公式仍可阅读。</p></noscript>
</section><!--interactive-end-->`;
export const materialLesson=`<!--interactive-start--><section class="field-lab" id="lab-material" aria-labelledby="material-title">
<header class="fl-head"><div><p class="fl-eyebrow">FIELD LAB / 02</p><h3 id="material-title">站着看，和跟着粒子看，有什么不同？</h3><p>同一个温度场：蓝色测点固定在起点，绿色粒子按给定速度运动。观察两者的温度历史。</p></div><button type="button" id="material-reset" class="fl-reset" aria-label="重置随体导数实验">↺</button></header>
<div class="fl-toolbar"><div class="fl-segments" role="group" aria-label="随体导数示例"><button type="button" data-material-preset="static" aria-pressed="true">静态场中穿行</button><button type="button" data-material-preset="follow" aria-pressed="false">粒子与波同速</button><button type="button" data-material-preset="heating" aria-pressed="false">原地升温</button></div><div class="fl-player"><button type="button" id="material-play" aria-pressed="false">▶ 播放</button><button type="button" id="material-step">+0.25 s</button></div></div>
<div class="fl-formula">${math(String.raw`\frac{DT}{Dt}=\underbrace{\frac{\partial T}{\partial t}}_{\text{local}}+\underbrace{u\frac{\partial T}{\partial x}}_{\text{advection}}`)}</div>
<div class="fl-dual-charts"><div><h4>此刻的空间截面 <span id="material-clock">t = 0.00 s</span></h4><svg id="material-space" viewBox="0 0 410 275" role="group" aria-label="当前温度场、固定测点和移动粒子"></svg></div><div><h4>两位观察者的温度历史</h4><svg id="material-history" viewBox="0 0 410 275" role="img" aria-label="固定测点与随体粒子的温度随时间变化"></svg></div></div>
<div class="fl-legend"><span class="fl-blue">固定测点 x₀</span><span class="fl-green">随体粒子 x(t)</span><span class="fl-tip">拖动蓝色测点重设起点；历史图淡线表示后续轨迹上的温度</span></div>
<div class="fl-derivative-sum"><div class="fl-local"><span>局部变化 ∂T/∂t</span><strong id="material-local">—</strong><small>°C/s</small></div><span class="fl-operator">+</span><div class="fl-advection"><span>对流变化 u ∂T/∂x</span><strong id="material-advection">—</strong><small>°C/s</small></div><span class="fl-operator">=</span><div class="fl-total"><span>随体导数 DT/Dt</span><strong id="material-total">—</strong><small>°C/s</small></div></div>
<p class="fl-location-note" id="material-location">三个导数项均在当前粒子位置与当前时刻计算。</p>
<div class="fl-controls fl-four">
${slider('material-u','粒子速度 u',-1.5,1.5,.1,1,'m/s')}
${slider('material-c','温度波速度 c',-1.5,1.5,.1,0,'m/s')}
${slider('material-source','均匀升温率 q',-1.5,1.5,.1,0,'°C/s')}
${slider('material-x0','共同起点 x₀',0,9.9,.1,1.2,'m')}
</div>
<div class="fl-time-control">${slider('material-time','时间 t',0,6,.01,0,'s')}</div>
<p class="fl-insight" id="material-insight" role="status"></p>
<details class="fl-model"><summary>解析场与导数</summary><p>${math(String.raw`T(x,t)=20+8\sin\!\left[\frac{2\pi}{10}(x-ct)\right]+qt,\quad x(t)=x_0+ut`)}。空间长度 10 m，周期显示；温度用 °C，速度用 m/s。时间范围 0–6 s，速度恒定。导数由解析式计算。调节速度、起点或升温率会从 t = 0 重新开始；拖动时间可回看。公式中的局部项取在当前粒子位置；蓝色固定测点位于 x₀，它的变化率通常不同。该温度场用于演示链式法则，并非求解热传导方程。</p></details>
<noscript><p>启用 JavaScript 后可播放粒子轨迹；正文公式仍可阅读。</p></noscript>
</section><!--interactive-end-->`;
