function control(id, label, min, max, step, value, unit) {
  return `<div class="control"><label for="${id}">${label}<span><output id="${id}-value" for="${id}">${value}</output> ${unit}</span></label><input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></div>`;
}
function header(number, title, text, reset) {
  return `<div class="lab-head"><div><p class="eyebrow">EXPERIMENT ${number}</p><h3>${title}</h3><p>${text}</p></div><button class="reset" data-reset="${reset}" type="button">重置 <span aria-hidden="true">↺</span></button></div>`;
}
function chart(id, label) {
  return `<svg id="${id}" class="lab-chart" viewBox="0 0 640 360" role="img" aria-label="${label}"></svg>`;
}
const disabled = '<noscript><p class="no-script">交互实验需要启用 JavaScript；正文、公式和插图仍可正常阅读。</p></noscript>';
export const densityLab = `<section class="lab" id="lab-density" aria-labelledby="density-title" data-lab="density">
${header('01', '<span id="density-title">让粒子靠近，密度如何变化？</span>', '保持每个粒子的质量不变，调整粒子间距与平滑长度。', 'density')}
<div class="lab-workspace"><div class="lab-controls">
${control('density-spacing', '粒子间距 Δx', .1, .55, .01, .3, 'm')}
${control('density-h', '平滑长度 h', .2, .7, .01, .45, 'm')}
<div class="metric"><span>中心密度 ρ(0)</span><strong id="density-result">—</strong><small>kg/m · 一维模型</small></div>
<p class="lab-assumption">9 个等质量粒子，m = 0.2 kg；采用归一化一维 cubic spline 核，支撑半径为 2h。</p>
</div><div class="lab-visual">${chart('density-chart', '一维粒子分布及其核加权密度曲线')}<div class="legend"><span class="legend-item teal">重建密度</span><span class="legend-item orange">中心粒子</span><span id="density-neighbors"></span></div></div></div>
<div class="lab-insight"><span>观察</span><p id="density-insight">中心位置的密度是邻域中所有粒子的核加权质量之和，包含自身贡献。</p></div>${disabled}</section>`;

export const eosLab = `<section class="lab" id="lab-eos" aria-labelledby="eos-title" data-lab="eos">
${header('02', '<span id="eos-title">很小的压缩，产生多大的压力？</span>', '移动取样点，比较 Tait 方程与同一声速下的线性近似。', 'eos')}
<div class="lab-workspace"><div class="lab-controls">
${control('eos-cs', '人工声速 cₛ', 10, 80, 1, 20, 'm/s')}
${control('eos-gamma', '非线性指数 γ', 1, 9, 1, 7, '')}
${control('eos-error', '密度偏差', -5, 8, .1, 1, '%')}
<div class="metric"><span>Tait 压力 p</span><strong id="eos-result">—</strong><small>kPa</small></div>
<p class="lab-assumption">ρ₀ = 1000 kg/m³；展示未截断压力。负压分支不代表所有自由表面实现都应保留负压。</p>
</div><div class="lab-visual">${chart('eos-chart', 'Tait 状态方程与线性压力近似的对比曲线')}<div class="legend"><span class="legend-item teal">Tait</span><span class="legend-item dashed">线性近似</span><span class="legend-item orange">当前密度</span></div><p class="axis-note">纵轴随声速自动缩放，实际压力见左侧数值。</p></div></div>
<div class="lab-insight"><span>观察</span><p id="eos-insight">声速加倍时，同一密度偏差对应的压力变为四倍。</p></div>${disabled}</section>`;

export const timestepLab = `<section class="lab" id="lab-timestep" aria-labelledby="timestep-title" data-lab="timestep">
${header('03', '<span id="timestep-title">哪一个条件限制了时间步？</span>', '改变声速、分辨率与黏度，观察四个时间步上限如何竞争。', 'timestep')}
<div class="lab-workspace"><div class="lab-controls">
${control('step-cs', '声速 cₛ', 5, 100, 1, 20, 'm/s')}
${control('step-h', '平滑长度 h', 5, 40, 1, 20, 'mm')}
${control('step-v', '最大速度', 0, 8, .1, 2, 'm/s')}
${control('step-nu', '运动黏度 ν', 0, 50000, 100, 0, 'mm²/s')}
<p class="lab-assumption">ρ = ρ₀ = 1000 kg/m³，a = 9.81 m/s²，σ = 0.072 N/m。示例系数：CFL、力、表面张力均为 0.25，黏性为 0.125。</p>
</div><div class="lab-visual time-visual"><div class="metric"><span>取最小上限 Δt</span><strong id="step-result">—</strong><small>ms</small></div><div id="step-bars" class="limit-bars" aria-label="时间步上限对比"></div><div class="step-summary"><span id="step-count">—</span><small>推进 1 秒物理时间的估算步数</small></div></div></div>
<div class="lab-insight"><span>观察</span><p id="step-insight">安全系数是教学示例，实际取值需要随核函数和积分方法校准。</p></div>${disabled}</section>`;
