# WCSPH：由密度误差驱动的显式压力反馈

> 本文以 Monaghan 1994 年的自由表面 SPH 方法和 Becker、Teschner 2007 年的 *Weakly Compressible SPH for Free Surface Flows* 为主要依据，从 SPH 的粒子表示开始，介绍 WCSPH 的物理动机、状态方程、空间离散、完整时间步、稳定性条件和边界处理。
>
> 原始论文：[Becker and Teschner 2007](https://doi.org/10.2312/SCA/SCA07/209-218)

WCSPH（Weakly Compressible Smoothed Particle Hydrodynamics）的核心不是严格求解不可压缩约束，而是允许粒子发生很小的密度变化，并通过状态方程立即产生压力反馈：

> 当前密度偏离参考密度以后，应产生多大的压力响应，才能抵抗进一步压缩？

它的基本闭环是：

```text
粒子分布发生变化
  → 密度偏离静止密度
  → 状态方程产生压力
  → 压力改变粒子速度和位置
  → 新的粒子分布重新决定密度
```

与基于不可压缩约束的压力求解方法不同，WCSPH 不要求每个时间步都精确满足 $\rho_i=\rho_0$ 和 $\nabla\cdot\mathbf v_i=0$。它通过人工声速调节压力反馈，使压缩引起的密度波动尽量接近用户设定的小量级；这不是对所有粒子、所有时刻的密度误差作严格保证。

---

## 1. SPH 表示连续流体

### 1.1 SPH 粒子

连续流体中，每个流体微团都有速度、密度和压力等物理量。SPH 不在固定网格上保存这些场，而是用一组随流体运动的拉格朗日粒子进行离散。

粒子 $i$ 通常携带位置 $\mathbf x_i$、速度 $\mathbf v_i$ 和守恒质量 $m_i$。密度 $\rho_i$ 由邻域粒子的空间分布估计，压力 $p_i$ 再由 WCSPH 的状态方程计算。

一个 SPH 粒子代表一小团随流体运动的有限质量。粒子质量、密度和当前有效体积满足：

$$
m_i=\rho_iV_i=\text{常数}.
\tag{1}
$$

因此，质量不变并不意味着密度不变。粒子周围的流体被压缩时，有效体积 $V_i$ 减小，密度 $\rho_i$ 增大；流体膨胀时则相反。

![SPH 粒子与真实水分子](./assets/sph-particle-vs-water-molecule/sph-particle-vs-water-molecule.png)

*图 1：真实水由大量微观分子组成；SPH 粒子不是单个水分子，而是有限质量流体微团的数值载体。虚线圆表示核支撑域，不是粒子的物理边界。*

### 1.2 从 Dirac $\delta$ 到平滑核

Dirac $\delta$ 是一种广义函数。它把全部权重集中在一个点上，并满足：

$$
\begin{aligned}
\delta(\mathbf r)&=0,
\qquad \mathbf r\neq\mathbf 0,\\
\int_{\mathbb R^d}\delta(\mathbf r)\,d\mathbf r&=1,\\
\int_{\mathbb R^d}A(\mathbf x')
\delta(\mathbf x-\mathbf x')\,d\mathbf x'
&=A(\mathbf x).
\end{aligned}
\tag{2}
$$

因此任意连续场 $A(\mathbf x)$ 都可以写成：

$$
A(\mathbf x)
=
\int_\Omega
A(\mathbf x')
\delta(\mathbf x-\mathbf x')\,dV'.
\tag{3}
$$

但是计算机中只有有限数量的粒子。如果直接使用 $\delta$，不与目标位置完全重合的粒子都没有贡献，也无法稳定计算梯度。因此 SPH 使用具有有限宽度的平滑核 $W$ 近似 $\delta$。

一个常用的有限支撑核函数通常满足：

$$
\begin{aligned}
\int_{\mathbb R^d} W(\mathbf r,h)\,d\mathbf r&=1,\\
W(\mathbf r,h)&=W(-\mathbf r,h),\\
W(\mathbf r,h)&=0
\quad\text{当 }\|\mathbf r\|\ge r_c.
\end{aligned}
\tag{4}
$$

其中 $h$ 是平滑长度，$r_c$ 是实际支撑半径。不同文献对 $h$ 的定义不同，有的直接令 $r_c=h$，有的使用 $r_c=2h$ 或其他倍数。实现时必须以所选核函数的定义为准。

这里的归一化是在整个空间上积分；对于有限支撑核，也等价于在完整核支撑域上积分。如果只在流体区域 $\Omega$ 内积分，靠近自由表面或固体边界时，核支撑域的一部分可能落在流体之外，积分就不一定等于 $1$。

![Dirac δ 与平滑核函数](./assets/wcsph-dirac-kernels/wcsph-dirac-kernels.png)

*图 2：平滑核随尺度缩小时逼近 Dirac $\delta$；右图比较几种常见径向核函数。图中的 Gaussian 是未截断的高斯核，用于说明平滑与核宽度；Cubic spline 和 Wendland C² 具有有限支撑。*

### 1.3 从连续积分到粒子求和

用平滑核替代 $\delta$ 后，连续场可以近似为：

$$
A(\mathbf x)
\approx
\int_\Omega
A(\mathbf x')W(\mathbf x-\mathbf x',h)\,dV'.
\tag{5}
$$

粒子 $j$ 当前的体积为 $V_j=m_j/\rho_j$。将连续积分离散成粒子求和，得到：

$$
\begin{gathered}
\boxed{
A_i
\approx
\sum_{j\in N_i}
A_j\frac{m_j}{\rho_j}W_{ij}
},\\[4pt]
W_{ij}=W(\mathbf x_i-\mathbf x_j,h).
\end{gathered}
\tag{6}
$$

式（6）中，每个邻居的贡献由三部分组成：邻居的场值 $A_j$、邻居代表的有效体积 $m_j/\rho_j$，以及距离权重 $W_{ij}$。

本文用 $N_i$ 表示核支撑域内的流体粒子集合，并约定包含粒子 $i$ 自身；固体边界的贡献另行处理。

![粒子采样与连续场重构](./assets/sph-discrete-continuous-field/sph-discrete-continuous-field.png)

*图 3：离散粒子表示连续场的概念示意。采样点与曲线用于说明采样和重构的关系，不对应一组给定核参数下的数值计算结果。*

### 1.4 SPH 如何计算密度

令式（6）中的待估计场量为密度，即 $A=\rho$，得到：

$$
\boxed{
\rho_i
=
\sum_{j\in N_i}m_jW_{ij}
}.
\tag{7}
$$

式（7）包含自身贡献 $m_iW(\mathbf 0,h)$。如果邻域搜索只返回其他粒子，计算密度时需要单独加回这一项。

因此，SPH 密度可以理解为粒子 $i$ 邻域内的所有粒子经过核函数加权后的质量：

- 邻居靠近时，核权重整体增大，密度通常上升；
- 邻居远离时，核权重整体减小，密度通常下降；
- 粒子质量没有改变，改变的是质量在空间中的局部分布。

粒子的有效体积随后由密度得到：

$$
V_i=\frac{m_i}{\rho_i}.
\tag{8}
$$


![粒子质量、密度与有效体积](./assets/sph-mass-density-volume/sph-mass-density-volume.png)

*图 4：粒子质量保持不变；邻域分布改变密度，密度再决定粒子代表的有效体积。*

---

## 2. 流体控制方程

### 2.1 粒子轨迹与物质导数

设连续场为 $A(\mathbf x,t)$，粒子 $i$ 沿轨迹 $\mathbf x_i(t)$ 运动。沿粒子轨迹求导，根据链式法则，将三个坐标方向的变化展开，有：

$$
\begin{aligned}
\frac{dA_i}{dt}
&=
\frac{\partial A}{\partial t}
+
v_{i,x}\frac{\partial A}{\partial x}
+
v_{i,y}\frac{\partial A}{\partial y}
+
v_{i,z}\frac{\partial A}{\partial z}\\[4pt]
&=
\frac{\partial A}{\partial t}
+
\mathbf v_i\cdot\nabla A
=
\frac{DA}{Dt}.
\end{aligned}
\tag{9}
$$

其中 $v_{i,x}=dx_i/dt$、$v_{i,y}=dy_i/dt$、$v_{i,z}=dz_i/dt$，分别是粒子在三个坐标方向上的速度分量。各偏导数均在粒子当前所在的位置 $\mathbf x_i(t)$、时刻 $t$ 处取值。

对应的粒子运动关系和物质导数算子为：

$$
\frac{d\mathbf x_i}{dt}=\mathbf v_i,
\qquad
\frac{D}{Dt}
=
\frac{\partial}{\partial t}
+
\mathbf v\cdot\nabla.
\tag{10}
$$

大写 $D/Dt$ 表示连续场的物质导数，小写 $d/dt$ 表示沿具体粒子轨迹对离散粒子状态求导。对拉格朗日粒子而言，两者描述同一个物理变化，但观察对象不同。

![物质导数与局部时间导数](./assets/material-vs-local-derivative/material-vs-local-derivative.png)

*图 5：局部时间导数、空间梯度和沿粒子轨迹的物质导数对应不同的时空方向。*

### 2.2 质量守恒与连续性方程

考虑一个随流体运动的物质微团，其质量 $m=\rho V$ 保持不变。速度散度给出物质微团的相对体积变化率，因此：

$$
\begin{aligned}
0=\frac{Dm}{Dt}
&=
V\frac{D\rho}{Dt}
+
\rho\frac{DV}{Dt},\\
\frac{1}{V}\frac{DV}{Dt}
&=
\frac{\partial v_x}{\partial x}
+
\frac{\partial v_y}{\partial y}
+
\frac{\partial v_z}{\partial z}
=
\nabla\cdot\mathbf v,\\
\therefore\qquad
\frac{D\rho}{Dt}
&=
-\rho\nabla\cdot\mathbf v.
\end{aligned}
\tag{11}
$$

第二行可以从一个足够小的长方体微团来理解：左右两侧的流速差决定它沿 $x$ 方向的伸缩，相对伸缩率为 $\partial v_x/\partial x$；另外两个方向同理。三个方向的相对伸缩率相加，就得到相对体积变化率 $(1/V)\,DV/Dt$，也就是速度散度。

即连续性方程：

- $\nabla\cdot\mathbf v<0$：局部压缩，密度增大；
- $\nabla\cdot\mathbf v>0$：局部膨胀，密度减小；
- $\nabla\cdot\mathbf v=0$：局部体积和密度保持不变。

严格不可压缩流体要求：

$$
\rho=\rho_0,
\qquad
\frac{D\rho}{Dt}=0,
\qquad
\nabla\cdot\mathbf v=0.
\tag{12}
$$

### 2.3 动量方程

连续流体的动量方程可以写成：

$$
\rho\frac{D\mathbf v}{Dt}
=
-\nabla p
+
\nabla\cdot\boldsymbol\tau
+
\mathbf f^{\mathrm{surface}}
+
\rho\mathbf g.
\tag{13}
$$

其中 $p$ 是压力，$\boldsymbol\tau$ 是黏性应力，$\mathbf f^{\mathrm{surface}}$ 是单位体积上的表面张力，$\mathbf g$ 是重力加速度。

对于恒温牛顿流体(例如：水)，在常黏度和常密度近似下，可以写成：

$$
\frac{D\mathbf v}{Dt}
=
-\frac{1}{\rho}\nabla p
+
\nu\nabla^2\mathbf v
+
\frac{\mathbf f^{\mathrm{surface}}}{\rho}
+
\mathbf g,
\tag{14}
$$

其中 $\nu$ 是运动黏度。

### 2.4 压力和速度的耦合

压力梯度改变速度；速度又更新位置和邻域，从而改变密度。直接用当前压力推进粒子，不能自动保证下一步仍满足不可压缩约束，因此需要选择相应的压力处理方式。WCSPH 允许少量密度变化，由状态方程直接提供压力反馈；DFSPH 等方法则通过迭代修正来满足相应约束。

![压力与速度的耦合关系](./assets/pressure-velocity-coupling/pressure-velocity-coupling.png)

*图 6：WCSPH 中，压力、速度、位置和密度形成闭环。*

在基于不可压缩约束的方法中，压力作为约束反力，通过全局耦合求解来修正流体运动。以 DFSPH 为例，它分别控制密度误差和速度散度误差，以设定的误差容限作为收敛标准 [7]。

WCSPH 则采用另一种处理方式：允许密度发生很小的变化，再通过局部状态方程直接计算压力。这样不需要在每个时间步求解压力 Poisson 方程，但会引入人工可压缩性和更严格的声学时间步限制。

下面用 WCSPH 说明完整的时间推进流程。

---

## 3. WCSPH 的核心：用状态方程近似不可压缩性

### 3.1 允许少量密度变化

WCSPH 保持粒子质量不变，但允许密度在参考值附近小幅变化，再通过压力抵抗进一步压缩。

也就是说，WCSPH 允许密度发生变化，但会让压力对密度变化足够敏感：密度只增加一点点，就能产生较大的压力，抵抗进一步压缩，让密度尽量维持在参考密度附近。这里关注的是密度偏离参考值的程度；如果只是每一步变化很小，偏差仍可能逐步累积。

这种反馈强弱由状态方程控制，通常通过人工声速来调节。人工声速越大，同样的密度增加产生的压力就越大，流体也就越难被压缩。

但反馈越强，对时间步的要求也越严格。显式模拟先根据当前密度计算压力，再用这个压力推进粒子的速度和位置。如果时间步太大，较强的压力可能把粒子推得过远，导致流体在压缩和膨胀之间反复振荡，甚至失稳。因此需要缩小时间步，更及时地重新计算密度和压力。这样一来，模拟相同的物理时间就需要更多步，计算成本也会增加。

选取人工声速时，先用 $\eta$ 表示希望控制的相对密度波动量级，实际相对密度偏差记为：

$$
\varepsilon_\rho=\frac{|\rho-\rho_0|}{\rho_0}.
\tag{15}
$$

在低 Mach 数流动的尺度估计中，压缩引起的密度变化与 Mach 数平方同阶 [1, 2]：

$$
\varepsilon_\rho\sim M^2=\frac{v_f^2}{c_s^2}.
\tag{16}
$$

其中 $v_f$ 是特征流速，$M=v_f/c_s$。因此，可根据场景的最大预期流速 $v_{\max}$ 选取：

$$
\boxed{c_s\gtrsim\frac{v_{\max}}{\sqrt{\eta}}}.
\tag{17}
$$

例如，$\eta=0.01$ 对应人工声速至少约为最大预期流速的 $10$ 倍。这里的 $v_{\max}$ 根据整个模拟过程中的驱动条件估计。若实际流速超过预估值，就需要重新评估人工声速和密度波动目标。

### 3.2 Tait 状态方程

Becker 和 Teschner 使用 Tait 状态方程：

$$
\boxed{
p_i
=
B
\left[
\left(
\frac{\rho_i}{\rho_0}
\right)^\gamma
-1
\right]
}.
\tag{18}
$$

其中 $\rho_0$ 是静止密度，$\gamma$ 控制非线性程度，液体模拟通常取：

$$
\gamma=7,
\qquad
B=\frac{\rho_0c_s^2}{\gamma}.
\tag{19}
$$

状态方程在当前密度附近对应的声速满足：

$$
c^2
=
\frac{\partial p}{\partial\rho}
=
\frac{B\gamma}{\rho_0}
\left(
\frac{\rho}{\rho_0}
\right)^{\gamma-1}.
\tag{20}
$$

在 $\rho=\rho_0$ 处，式（19）使 $c=c_s$。

当密度只在 $\rho_0$ 附近小幅变化时，对 Tait 方程线性化可得：

$$
p
\approx
c_s^2(\rho-\rho_0).
\tag{21}
$$

因此 Tait 方程可以理解为一种非线性的弹性压力反馈：密度越高，压力增长越快；参数 $c_s$ 越大，流体越难被压缩。

### 3.3 线性状态方程与 Tait 方程的区别

简单实现有时使用线性状态方程：

$$
p_i
=
k_p(\rho_i-\rho_0).
\tag{22}
$$

当 $k_p=c_s^2$ 时，它与 Tait 方程在 $\rho_0$ 附近的一阶线性化一致。但是密度偏差较大时，线性模型的压力增长不如 Tait 方程迅速，更容易出现明显压缩。

两者均是可选的压力闭合方式。

### 3.4 负压力和压力截断

当密度求和得到 $\rho_i<\rho_0$ 时，式（18）会产生负压力。负压力具有吸引作用，在某些模型中有物理意义，但也可能加剧 SPH 的 tensile instability，使粒子聚团。

许多自由表面实现会使用：

$$
p_i
=
\max\left(
0,
B\left[
\left(\frac{\rho_i}{\rho_0}\right)^\gamma-1
\right]
\right).
\tag{23}
$$

这种截断可以减小自由表面处由核支撑缺失产生的非物理吸引，但它不是 WCSPH 定义中唯一允许的选择，也会去掉真实的负压状态。需要根据自由表面、空化和多相流的建模目标决定是否使用。

采用截断后，低于 $\rho_0$ 的粒子不会因自身密度偏低而产生负压力反馈，因此不能指望截断后的状态方程自动把所有偏低的密度恢复到 $\rho_0$。

---

## 4. WCSPH 控制方程的粒子离散

### 4.1 邻居记号与核梯度

对粒子 $i$ 及其邻居 $j$，定义：

$$
\begin{aligned}
\mathbf r_{ij}&=\mathbf x_i-\mathbf x_j,
\\
r_{ij}&=\|\mathbf r_{ij}\|,\\
\mathbf v_{ij}&=\mathbf v_i-\mathbf v_j,
\\
W_{ij}&=W(\mathbf r_{ij},h).
\end{aligned}
\tag{24}
$$

对于径向对称核，交换粒子顺序会使核梯度反向：

$$
\nabla_jW_{ji}
=
-\nabla_iW_{ij}.
\tag{25}
$$

这一反对称性是构造守恒粒子对力的基础。

### 4.2 密度的两种更新方式

先在不计固体边界贡献时说明两种更新方式。密度求和形式直接根据当前位置计算，并包含粒子自身：

$$
\rho_i
=
\sum_{j\in N_i}m_jW_{ij}.
\tag{26}
$$

也可以把密度作为粒子状态，通过离散连续性方程随时间积分：

$$
\frac{d\rho_i}{dt}
=
\sum_{j\in N_i}
m_j
(\mathbf v_i-\mathbf v_j)
\cdot\nabla_iW_{ij}.
\tag{27}
$$

两者表达相同的质量变化机制，但数值性质不同：

- 密度求和始终与当前粒子位置直接对应，通常更加稳定，但在自由表面和固体边界处会受到核支撑缺失影响；
- 连续性方程形式只由粒子相对运动改变密度，自由表面初始密度更容易保持正确，但会积累时间积分和离散散度误差。

Becker 和 Teschner 比较两种方式后，在实验中采用了密度求和。本文后续完整流程也采用这种方式；若所选边界模型需要密度补偿，则在式（26）的流体粒子求和之外，再加上该模型的边界贡献。

### 4.3 压力梯度的对称离散

连续压力加速度为 $-(1/\rho)\nabla p$。先只写流体粒子之间的贡献，记为 $\mathbf a_i^{p,F}$；常用的对称 SPH 离散为：

$$
\boxed{
\mathbf a_i^{p,F}
=
-\sum_{j\in N_i}
m_j
\left(
\frac{p_i}{\rho_i^2}
+
\frac{p_j}{\rho_j^2}
\right)
\nabla_iW_{ij}
}.
\tag{28}
$$

粒子 $j$ 对粒子 $i$ 的压力作用写成真实力为：

$$
\begin{aligned}
\mathbf F_{ij}^p
&=
-m_im_j
\left(
\frac{p_i}{\rho_i^2}
+
\frac{p_j}{\rho_j^2}
\right)
\nabla_iW_{ij},\\
\mathbf F_{ji}^p
&=
-\mathbf F_{ij}^p.
\end{aligned}
\tag{29}
$$

括号中的系数关于 $i,j$ 对称，而核梯度满足式（25），所以粒子对压力力成对反向，离散线动量得以守恒。对于径向核，压力力沿粒子连线，也不会产生额外的粒子对力矩。


### 4.4 物理黏性

黏性用于扩散动量并减小邻近粒子的速度差。只考虑流体粒子之间的贡献时，一种直接 Laplacian 离散为：

$$
\mathbf a_i^{\mathrm{visc},F}
=
\nu
\sum_{j\ne i}
\frac{m_j}{\rho_j}
(\mathbf v_j-\mathbf v_i)
\nabla^2W_{ij}.
\tag{30}
$$

如果使用 Müller 等人提出的专用 viscosity kernel，其三维 Laplacian 为：

$$
\nabla^2W_{\mathrm{visc}}(r,h)
=
\begin{cases}
\dfrac{45}{\pi h^6}(h-r),
&0\le r<h,\\[4pt]
0,
&r\ge h.
\end{cases}
\tag{31}
$$

由于支撑域内的 Laplacian 非负，式（30）会把粒子速度拉向邻居速度。所有粒子具有相同速度时，速度差为零，因此黏性不会阻碍整体匀速平移。

### 4.5 人工黏性

原始 WCSPH 论文使用人工黏性增强冲击和高压缩区域的稳定性。它只在两个粒子互相靠近时起作用：

$$
\mathbf a_i^{\mathrm{av}}
=
-\sum_{j\in N_i}m_j\Pi_{ij}\nabla_iW_{ij}.
\tag{32}
$$

一种常见的 Monaghan 型系数为：

$$
\Pi_{ij}
=
\begin{cases}
-\dfrac{\alpha_{\mathrm{av}}c_s h}
{\bar\rho_{ij}}
\dfrac{\mathbf v_{ij}\cdot\mathbf r_{ij}}
{r_{ij}^2+\epsilon h^2},
&\mathbf v_{ij}\cdot\mathbf r_{ij}<0,\\[6pt]
0,
&\mathbf v_{ij}\cdot\mathbf r_{ij}\ge0.
\end{cases}
\tag{33}
$$

其中 $\bar\rho_{ij}=(\rho_i+\rho_j)/2$，$\epsilon>0$ 是无量纲正则化参数，用于避免两个粒子距离趋零时分母过小。靠近或远离的条件针对每一对粒子分别判断，再把各对粒子的贡献相加。

人工黏性和物理黏性都具有耗散作用，但含义不同：物理黏性用于近似材料黏度，人工黏性主要用于数值稳定。实际实现可以只使用其中一种，也可以在明确标定后组合使用。

### 4.6 表面张力

表面张力不是 WCSPH 压力闭合的必要组成部分，而是可选的非压力模型。常见 color field 形式先计算：

$$
c_i
=
\sum_j\frac{m_j}{\rho_j}W_{ij}.
\tag{34}
$$

再由 color field 得到表面法向和曲率相关量：

$$
\begin{aligned}
\mathbf n_i
&=
\sum_j\frac{m_j}{\rho_j}\nabla_iW_{ij},\\[4pt]
\nabla^2c_i
&=
\sum_j\frac{m_j}{\rho_j}\nabla_i^2W_{ij}.
\end{aligned}
\tag{35}
$$

当 $\|\mathbf n_i\|$ 大于阈值时，一种连续表面力离散为：

$$
\mathbf a_i^{\mathrm{surface}}
=
-\frac{\sigma}{\rho_i}
(\nabla^2c_i)
\frac{\mathbf n_i}{\|\mathbf n_i\|}.
\tag{36}
$$

曲率、法向和二阶核导数在无序粒子和自由表面附近容易产生噪声。Becker 和 Teschner 还提出了适合单相自由表面的 cohesion 模型。具体表面张力模型应独立选择，不能把式（36）理解为 WCSPH 唯一允许的形式。

### 4.7 总加速度

这里统一把边界压力计入压力项，把边界黏性计入物理黏性项，即 $\mathbf a_i^p=\mathbf a_i^{p,F}+\mathbf a_i^{p,B}$、$\mathbf a_i^{\mathrm{visc}}=\mathbf a_i^{\mathrm{visc},F}+\mathbf a_i^{\mathrm{visc},B}$；上标 $F$ 和 $B$ 分别表示流体与边界贡献。总加速度为：

$$
\boxed{
\frac{d\mathbf v_i}{dt}
=
\mathbf a_i^p
+
\mathbf a_i^{\mathrm{visc}}
+
\mathbf a_i^{\mathrm{av}}
+
\mathbf a_i^{\mathrm{surface}}
+
\mathbf g
}.
\tag{37}
$$

不是所有实现都必须启用每一项。WCSPH 的核心只有粒子密度、状态方程压力、压力梯度和时间积分；其余项由具体物理场景决定。

上述归类对应后文伪代码采用的边界压力与黏性处理方式，同一边界贡献不再单独累加一次。几何碰撞造成的位置和速度修正另在积分之后处理，不写成式（37）中的加速度项。

---

## 5. 一个时间步的完整流程

### 5.1 初始化

第一个时间步开始前，准备粒子位置、速度、质量、参考密度、核参数和边界表示，并根据初始位置建立邻域、计算密度和压力。如果初始粒子排列使密度明显偏离 $\rho_0$，模拟一开始就可能产生很大的压力波。

### 5.2 每个时间步的执行顺序

以密度求和和半隐式 Euler 积分为例，一个时间步的核心顺序如下：

![WCSPH 计算闭环](./assets/wcsph-computation-loop/wcsph-computation-loop.png)

*图 7：WCSPH 一个时间步的核心流程。边界贡献、负压力截断与可选碰撞修正见下一章伪代码。*

各阶段按顺序完成：先计算所有粒子的密度和压力，再基于同一时刻的状态计算加速度、选择时间步，最后统一更新速度和位置。位置更新后，下一时间步重新搜索邻域，并计算新的密度和压力。

将式（37）的总加速度用于半隐式 Euler 更新：

$$
\boxed{
\begin{aligned}
\mathbf v_i^{n+1}
&=
\mathbf v_i^n+\Delta t^n\mathbf a_i^n,\\
\mathbf x_i^{n+1}
&=
\mathbf x_i^n+\Delta t^n\mathbf v_i^{n+1}.
\end{aligned}
}
\tag{38}
$$

这里使用半隐式 Euler 演示时间推进；Becker 和 Teschner 的实验采用 Leap-frog 积分 [1]。

在这个过程中，压力由当前密度通过状态方程直接得到，不需要迭代求解全局压力系统。压力与其他作用共同改变粒子运动，更新位置后的密度误差则在下一时间步重新计算并产生反馈。

因此，WCSPH 不在每一步强制满足 $\rho_i=\rho_0$ 和 $\nabla\cdot\mathbf v_i=0$，而是允许小幅密度变化，通过压力反馈近似不可压缩性。DFSPH 等方法则通过迭代修正，满足相应的密度或速度约束。

---

## 6. 实现伪代码

以下以固定固体边界为例，采用密度求和、Tait 状态方程和半隐式 Euler 积分；黏性使用式（30）的物理黏性，表面张力按需启用。

时间步需要同时考虑压力传播、加速度、黏性和表面张力，取各项允许上限中的最小值。人工声速越大，压力传播越快，通常需要越小的时间步。未启用的物理项不参与限制；安全系数根据核函数和积分方法选择。

```text
initialize particles x, v, m
initialize boundary representation
initialize rho0, h, support radius, gamma, eta
initialize nu, sigma, C_CFL, C_force, C_visc, C_surface
estimate positive vmax_expected from scene scale and driving forces
cs = vmax_expected / sqrt(eta)  # 可提高；不能只根据初始流速选取
B  = rho0 * cs * cs / gamma

while simulation is running:
    build_neighbor_search(x)  # 若采用边界样本，同时查询边界邻域

    parallel for each fluid particle i:
        rho[i] = sum_fluid_density(i)  # 包含自身项 m[i] * W(0, h)
        rho[i] += boundary_density_contribution(i)  # 按所选边界模型加入；不采用时为 0

    parallel for each fluid particle i:
        pressure[i] = B * ((rho[i] / rho0)^gamma - 1)
        if negative_pressure_is_disabled:
            pressure[i] = max(pressure[i], 0)

    parallel for each fluid particle i:
        acceleration[i] = gravity
        acceleration[i] += pressure_acceleration(i)   # 按所选模型计入边界压力贡献
        if nu > 0:
            acceleration[i] += viscosity_acceleration(i)  # 含边界黏性贡献
        if sigma > 0:
            acceleration[i] += surface_tension_acceleration(i)

    v_step = max_i length(v[i])  # 当前步最大速度大小，区别于 vmax_expected
    a_step = max_i length(acceleration[i])  # 当前步最大总加速度大小
    c_step = max(cs, max_i tait_sound_speed(rho[i]))  # 式（20）的声速取最大值，且至少取 cs
    acoustic_limit = C_CFL * h / (c_step + v_step)
    # 未启用或分母为零的限制保留为 infinity，不影响取最小值
    force_limit = infinity
    viscosity_limit = infinity
    surface_tension_limit = infinity
    if a_step > 0:
        force_limit = C_force * sqrt(h / a_step)
    if nu > 0:
        viscosity_limit = C_visc * h * h / nu
    if sigma > 0:
        surface_tension_limit = C_surface * sqrt(rho0 * h^3 / sigma)

    dt = min(
        acoustic_limit,
        force_limit,
        viscosity_limit,
        surface_tension_limit
    )

    parallel for each fluid particle i:
        v[i] = v[i] + dt * acceleration[i]
        x[i] = x[i] + dt * v[i]

    if geometric_collision_correction_is_enabled:
        parallel for each fluid particle i:
            x[i], v[i] = resolve_boundary_collision(x[i], v[i])
```

可选的碰撞修正用于调整穿透位置和碰撞速度，修正后的状态用于下一时间步。

---

## 7. 总结

SPH 用随流体运动的粒子表示连续流体。粒子携带的质量保持不变，局部密度通过邻域内的核加权质量求和得到，并随粒子分布的变化而变化。

WCSPH 允许密度在参考值附近小幅波动，再用状态方程计算压力。密度升高时，压力反馈增强；压力梯度与重力、黏性等作用共同改变粒子的速度和位置，抑制进一步压缩。位置更新后，新的粒子分布又决定下一步的密度和压力，形成持续的反馈过程。

这种方法可以由当前密度直接求出压力，无需在每个时间步迭代求解全局压力系统。它通过有限的密度变化近似不可压缩性：人工声速越大，压力对密度变化越敏感，流体越难被压缩；但显式积分通常也需要更小的时间步，模拟相同时间的计算成本随之增加。

---

## 8. 符号索引

本文使用粗体表示向量，普通斜体表示标量。时间步上标、粒子索引和物理项上标具有不同含义。

### 8.1 粒子索引和时间记号

| 记号 | 含义 |
|---|---|
| $i$ | 当前讨论的流体粒子 |
| $j$ | 核支撑域内的流体粒子索引，密度求和包含 $j=i$ |
| $n$、$n+1$ | 当前时间步和下一时间步 |
| $N_i$ | 粒子 $i$ 的流体邻域集合，包含自身 |
| 上标 $p$ | 压力产生的量 |
| 上标 $F$、$B$ | 相应力项中的流体贡献和边界贡献 |
| 上标 $\mathrm{other}$ | 已启用的非压力项之和 |
| 上标 $\mathrm{visc}$ | 物理黏性项 |
| 上标 $\mathrm{av}$ | 人工黏性项 |

### 8.2 粒子状态和材料参数

| 符号 | 含义 |
|---|---|
| $\mathbf x_i$ | 粒子位置 |
| $\mathbf v_i$ | 粒子速度 |
| $\mathbf a_i$ | 粒子总加速度 |
| $m_i$ | 粒子携带的守恒质量 |
| $V_i$ | 粒子当前代表的有效积分体积，$m_i/\rho_i$ |
| $\rho_i$ | 粒子密度 |
| $\rho_0$ | 静止密度或参考密度 |
| $p_i$ | 由状态方程计算的粒子压力 |
| $\mathbf g$ | 重力加速度 |
| $\nu$ | 运动黏度 |
| $\sigma$ | 表面张力系数 |
| $\alpha_{\mathrm{av}}$ | 人工黏性系数 |
| $\epsilon$ | 人工黏性分母中的无量纲正则化参数 |
| $\boldsymbol\tau$ | 黏性应力张量 |
| $\mathbf f^{\mathrm{surface}}$ | 单位体积上的表面张力 |
| $c_i$ | 表面张力模型中的 color field 值 |
| $\mathbf n_i$ | color field 的梯度，归一化后给出法向方向 |

### 8.3 状态方程和时间步

| 符号 | 含义 |
|---|---|
| $c_s$ | WCSPH 使用的人工声速 |
| $c$ | 由状态方程斜率得到的当前密度下的声速，与 color field $c_i$ 区分 |
| $v_{\max}$ | 场景的最大预期流速 |
| $v_f$ | 低 Mach 数尺度估计中的特征流速 |
| $B$ | Tait 状态方程的压力常数，$\rho_0c_s^2/\gamma$ |
| $\gamma$ | Tait 状态方程指数，液体常用值为 $7$ |
| $k_p$ | 线性状态方程刚度 |
| $\eta$ | 目标相对密度波动 |
| $\varepsilon_\rho$ | 实际相对密度偏差，$\lvert\rho-\rho_0\rvert/\rho_0$ |
| $M$ | Mach 数，$v_f/c_s$ |
| $\Delta t$ | 当前时间步长度 |
| `v_step`、`a_step` | 伪代码中当前步的最大速度大小和最大总加速度大小 |
| `c_step` | 伪代码中用于声学限制的声速上界，至少取 $c_s$ |
| `C_CFL` | 声学 CFL 安全系数 |
| `C_force`、`C_visc`、`C_surface` | 加速度、黏性和表面张力时间步限制的安全系数 |
| `acoustic_limit` | 声学传播给出的时间步上限 |
| `force_limit` | 加速度给出的时间步上限 |
| `viscosity_limit` | 黏性扩散给出的时间步上限 |
| `surface_tension_limit` | 毛细波给出的时间步上限 |

### 8.4 核函数和粒子对

| 符号 | 含义 |
|---|---|
| $W_{ij}$ | 粒子 $i$ 和 $j$ 之间的核函数值 |
| $\nabla_iW_{ij}$ | 核函数关于中心粒子位置 $\mathbf x_i$ 的梯度 |
| $\nabla_i^2W_{ij}$ | 核函数 Laplacian |
| $h$ | 平滑长度；与支撑半径的比例由核函数定义决定 |
| $r_c$ | 核函数实际支撑半径 |
| $\mathbf r_{ij}$ | 相对位置，$\mathbf x_i-\mathbf x_j$ |
| $r_{ij}$ | 粒子间距离，$\|\mathbf r_{ij}\|$ |
| $\mathbf v_{ij}$ | 相对速度，$\mathbf v_i-\mathbf v_j$ |
| $\mathbf F_{ij}^p$ | 粒子 $j$ 对粒子 $i$ 的压力作用力 |
| $\Pi_{ij}$ | 人工黏性粒子对系数 |
| $\bar\rho_{ij}$ | 粒子对的平均密度，$(\rho_i+\rho_j)/2$ |
| $\|\cdot\|$ | 欧氏范数 |
| $\cdot$ | 向量点积 |

---

## 9. 参考文献

正文的 WCSPH 状态方程与人工声速选择主要依据文献 [1] 和 [2]；SPH 基础、核离散和非压力项参考文献 [3]–[6]。第 6 章伪代码采用常用的时间步尺度估计，与文献 [1] 中配合人工黏性的原始时间步公式不同。

Reference:

[1] Becker, M., and Teschner, M. **Weakly Compressible SPH for Free Surface Flows**. *ACM SIGGRAPH / Eurographics Symposium on Computer Animation*, 2007, pp. 209–218. [论文 PDF](https://cg.informatik.uni-freiburg.de/publications/2007_SCA_SPH.pdf) · [DOI](https://doi.org/10.2312/SCA/SCA07/209-218)

[2] Monaghan, J. J. **Simulating Free Surface Flows with SPH**. *Journal of Computational Physics*, 110(2), 1994, pp. 399–406. [DOI](https://doi.org/10.1006/jcph.1994.1034)

[3] Monaghan, J. J. **Smoothed Particle Hydrodynamics**. *Annual Review of Astronomy and Astrophysics*, 30, 1992, pp. 543–574. [DOI](https://doi.org/10.1146/annurev.aa.30.090192.002551)

[4] Monaghan, J. J. **Smoothed Particle Hydrodynamics**. *Reports on Progress in Physics*, 68(8), 2005, pp. 1703–1759. [DOI](https://doi.org/10.1088/0034-4885/68/8/R01)

[5] Müller, M., Charypar, D., and Gross, M. **Particle-Based Fluid Simulation for Interactive Applications**. *ACM SIGGRAPH / Eurographics Symposium on Computer Animation*, 2003, pp. 154–159. [DOI](https://doi.org/10.2312/SCA03/154-159)

[6] Koschier, D., Bender, J., Solenthaler, B., and Teschner, M. **Smoothed Particle Hydrodynamics Techniques for the Physics Based Simulation of Fluids and Solids**. *Eurographics 2019 – Tutorials*, 2019, pp. 1–41. [DOI](https://doi.org/10.2312/egt.20191035) · [arXiv 版本（2020）](https://arxiv.org/abs/2009.06944)

[7] Bender, J., and Koschier, D. **Divergence-Free Smoothed Particle Hydrodynamics**. *ACM SIGGRAPH / Eurographics Symposium on Computer Animation*, 2015, pp. 147–155. [DOI](https://doi.org/10.1145/2786784.2786796)
