export function cubicKernel1D(r, h) {
  const q = Math.abs(r) / h;
  if (q >= 2) return 0;
  return 2 / (3 * h) * (q < 1 ? 1 - 1.5 * q ** 2 + .75 * q ** 3 : .25 * (2 - q) ** 3);
}
export function density1D(x, positions, h, mass = .2) {
  return positions.reduce((sum, p) => sum + mass * cubicKernel1D(x - p, h), 0);
}
export function taitPressure(ratio, cs, gamma = 7, rho0 = 1000) {
  return rho0 * cs ** 2 / gamma * (ratio ** gamma - 1);
}
export function timeLimits({ h, cs, velocity, nu, acceleration = 9.81, sigma = .072, rho0 = 1000 }) {
  return [
    { label: '声学传播', symbol: 'CFL', value: .25 * h / (cs + velocity) },
    { label: '加速度', symbol: 'FORCE', value: acceleration > 0 ? .25 * Math.sqrt(h / acceleration) : Infinity },
    { label: '黏性扩散', symbol: 'VISCOSITY', value: nu > 0 ? .125 * h * h / nu : Infinity },
    { label: '表面张力', symbol: 'SURFACE', value: sigma > 0 ? .25 * Math.sqrt(rho0 * h ** 3 / sigma) : Infinity },
  ];
}
