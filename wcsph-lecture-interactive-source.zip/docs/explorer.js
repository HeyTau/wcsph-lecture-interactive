import {RHO0,MASS,DEFAULT_H,kernel2D,makeParticles,compute,contributions,advance} from './solver.mjs';
const $=id=>document.getElementById(id);
const fmt=(v,d=2)=>Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const set=(id,text)=>{$(id).textContent=text;};
const svgNS='http://www.w3.org/2000/svg';
function svgNode(tag,attrs={},text) {const n=document.createElementNS(svgNS,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,String(v));if(text!==undefined)n.textContent=text;return n;}
const sx=x=>100+x*460,sy=y=>25+(1-y)*460;
const config={h:DEFAULT_H,cs:20,gamma:7,nu:0};
let scene='compressed',stage='kernel',selected=63,activeNeighbor=64,particles=makeParticles(scene),fields=compute(particles,config),running=false,time=0,steps=0,raf=0;
let ghosts=particles.map(p=>({...p})),trace=[],lastStep=null,dragging=false;
const stageInfo={
particles:{title:'位置变了，后面都跟着变',desc:'拖动任意粒子，改变它与邻居的距离。质量保持不变，密度由新的空间分布重新计算。',view:'粒子位置',key:'选中粒子 · 邻域内粒子',ref:'section-1'},
kernel:{title:'每个邻居，贡献多少？',desc:'核函数把距离转成权重。选中一个邻居，查看它在核曲线上的位置；支撑域以外的贡献为零。',view:'粒子邻域',key:'距离越近，贡献越大',ref:'section-1'},
density:{title:'把邻居的贡献，一项项相加',desc:'每一段色条对应一个粒子的核加权质量。粒子自身也参与求和；点选色条，与左侧位置对照。',view:'密度分布',key:'密度 600 → 1200 kg/m³',ref:'section-4'},
pressure:{title:'密度误差，变成压力反馈',desc:'圆点就是当前粒子。移动粒子会沿曲线改变压力；提高声速，会让同样的压缩产生更强的反馈。',view:'压力分布',key:'压力 0 → 80 kPa',ref:'section-3'},
integrate:{title:'有了压力，然后真的动起来',desc:'箭头表示加速度方向，长度随大小缩放。点击步进，先更新速度，再更新位置；下一步重新计算密度。',view:'压力力与运动',key:'箭头 = 加速度 · 细线 = 轨迹',ref:'section-5'}
};
const canvas=$('particle-canvas'),dots=[];
$('scene-particles').replaceChildren();
for(let i=0;i<121;i++) {
  const g=svgNode('g',{'data-particle':i,class:'scene-particle',role:'button',tabindex:i===selected?0:-1,'aria-label':'粒子 '+i});
  g.append(svgNode('circle',{r:12,fill:'transparent'}),svgNode('circle',{r:4.4,class:'particle-dot'}));dots.push(g);$('scene-particles').append(g);
}
const grid=$('scene-grid');
for(let k=0;k<=10;k++){const v=k/10;grid.append(svgNode('line',{x1:sx(v),x2:sx(v),y1:sy(0),y2:sy(1),stroke:'#e1e7de','stroke-width':.7}),svgNode('line',{x1:sx(0),x2:sx(1),y1:sy(v),y2:sy(v),stroke:'#e1e7de','stroke-width':.7}));}
grid.append(svgNode('rect',{x:sx(0),y:sy(1),width:460,height:460,fill:'none',stroke:'#c4d2c5'}));
grid.append(svgNode('text',{x:sx(0),y:16,class:'plot-label'},'y / m'),svgNode('text',{x:sx(1)+13,y:sy(0)+4,class:'plot-label'},'x'));
for(const v of [0,.5,1])grid.append(svgNode('text',{x:sx(v),y:503,'text-anchor':'middle',class:'plot-label'},v),svgNode('text',{x:85,y:sy(v)+4,'text-anchor':'end',class:'plot-label'},v));
function mixColor(t){t=Math.max(0,Math.min(1,t));const a=[214,226,210],b=[22,113,100];return 'rgb('+a.map((v,i)=>Math.round(v+(b[i]-v)*t)).join(',')+')';}
function arrow(group,a,vector,scale,color) {
  const len=Math.hypot(vector.x,vector.y);if(len<1e-7)return;
  const dx=vector.x*scale,dy=-vector.y*scale,x=sx(a.x),y=sy(a.y),angle=Math.atan2(dy,dx);
  group.append(svgNode('line',{x1:x,y1:y,x2:x+dx,y2:y+dy,stroke:color,'stroke-width':1.2,'stroke-opacity':.7}));
  group.append(svgNode('path',{d:`M${x+dx-4*Math.cos(angle-.45)},${y+dy-4*Math.sin(angle-.45)} L${x+dx},${y+dy} L${x+dx-4*Math.cos(angle+.45)},${y+dy-4*Math.sin(angle+.45)}`,stroke:color,fill:'none','stroke-width':1.2}));
}
function renderScene() {
  const p=particles[selected],neighborData=contributions(particles,selected,config.h);
  const ids=new Set(neighborData.map(v=>v.id));if(!ids.has(activeNeighbor))activeNeighbor=neighborData.find(v=>v.id!==selected)?.id??selected;
  const support=$('scene-support'),links=$('scene-links'),labels=$('scene-labels'),tails=$('scene-trails');
  support.replaceChildren();links.replaceChildren();labels.replaceChildren();tails.replaceChildren();
  if(stage!=='integrate') {
    support.append(svgNode('circle',{cx:sx(p.x),cy:sy(p.y),r:2*config.h*460,fill:'#70a993','fill-opacity':.07,stroke:'#78a28f','stroke-dasharray':'3 5','stroke-width':1}));
    support.append(svgNode('line',{x1:sx(p.x),y1:sy(p.y),x2:sx(p.x)+2*config.h*460,y2:sy(p.y),stroke:'#91b5a0','stroke-dasharray':'3 4'}));
    labels.append(svgNode('text',{x:sx(p.x)+config.h*460,y:sy(p.y)-7,'text-anchor':'middle',class:'plot-label'},'2h'));
  }
  const maxA=Math.max(1,...fields.acceleration.map(a=>Math.hypot(a.x,a.y)));
  particles.forEach((q,i)=>{
    const inside=ids.has(i),current=i===selected,neighbor=i===activeNeighbor;
    let fill=stage==='density'?mixColor((fields.rho[i]-600)/600):stage==='pressure'?mixColor(fields.pressure[i]/80000):inside?mixColor(kernel2D(Math.hypot(q.x-p.x,q.y-p.y),config.h)/kernel2D(0,config.h)):'#cbd6cd';
    if(current)fill='#b97c3f';else if(neighbor&&stage!=='integrate')fill='#6e9d85';
    const g=dots[i];g.setAttribute('transform',`translate(${sx(q.x)},${sy(q.y)})`);g.setAttribute('tabindex',current?0:-1);g.setAttribute('aria-pressed',String(current));
    const dot=g.lastChild;dot.setAttribute('fill',fill);dot.setAttribute('r',current?6:4.3);dot.setAttribute('stroke',current||neighbor?'#f5f7f3':'none');dot.setAttribute('stroke-width',current?2:1.5);
    if(inside&&!current&&(stage==='kernel'||stage==='density'))links.append(svgNode('line',{x1:sx(p.x),y1:sy(p.y),x2:sx(q.x),y2:sy(q.y),stroke:neighbor?'#b97c3f':'#87aa96','stroke-opacity':neighbor?.9:.22,'stroke-width':neighbor?1.5:.7}));
    if(stage==='integrate') {
      arrow(links,q,fields.acceleration[i],32/maxA,i===selected?'#b97c3f':'#639282');
      const start=ghosts[i];tails.append(svgNode('line',{x1:sx(start.x),y1:sy(start.y),x2:sx(q.x),y2:sy(q.y),stroke:'#94afa0','stroke-opacity':.32,'stroke-width':1}));
    }
  });
  support.append(svgNode('circle',{cx:sx(p.x),cy:sy(p.y),r:11,fill:'none',stroke:'#b97c3f','stroke-width':1,'stroke-opacity':.6}));
  labels.append(svgNode('text',{x:sx(p.x)+13,y:sy(p.y)-13,fill:'#a56935','font-size':14,'font-family':'Consolas,monospace'},'i = '+selected));
  if(stage!=='integrate'&&activeNeighbor!==selected) {const q=particles[activeNeighbor];labels.append(svgNode('text',{x:sx(q.x)+10,y:sy(q.y)+19,fill:'#5b8870','font-size':12,'font-family':'Consolas,monospace'},'j = '+activeNeighbor));}
  if(stage==='integrate'&&trace.length>1)tails.append(svgNode('polyline',{points:trace.map(v=>sx(v.x)+','+sy(v.y)).join(' '),stroke:'#b97c3f','stroke-width':1.5,fill:'none'}));
  set('particle-position',`x = ${fmt(p.x,3)}, y = ${fmt(p.y,3)} m`);set('neighbor-count',(neighborData.length-1)+' 个邻居');
  $('selected-particle').value=selected;
  return neighborData;
}
function chartBase(xmin,xmax,ymax,xlabel,ylabel) {
  const chart=$('trace-chart');chart.replaceChildren();const x=v=>40+(v-xmin)/(xmax-xmin)*375,y=v=>145-v/ymax*111;
  for(let i=0;i<=3;i++) {let v=ymax*i/3;chart.append(svgNode('line',{x1:40,x2:415,y1:y(v),y2:y(v),class:'plot-grid'}),svgNode('text',{x:30,y:y(v)+4,'text-anchor':'end',class:'plot-label'},fmt(v,ymax<5?1:0)));}
  for(let i=0;i<=4;i++){let v=xmin+(xmax-xmin)*i/4;chart.append(svgNode('text',{x:x(v),y:163,'text-anchor':'middle',class:'plot-label'},fmt(v,xmax>50?0:2)));}
  chart.append(svgNode('text',{x:40,y:18,class:'plot-title'},ylabel),svgNode('text',{x:415,y:183,'text-anchor':'end',class:'plot-label'},xlabel));
  return {chart,x,y};
}
function drawCurve(c,f,lo,hi,attrs={}){let d='';for(let i=0;i<=100;i++){let v=lo+(hi-lo)*i/100;d+=(i?'L':'M')+c.x(v)+','+c.y(f(v));}c.chart.append(svgNode('path',{d,class:'plot-curve',...attrs}));}
function result(label,value,unit){$('trace-result').replaceChildren();const l=document.createElement('span'),v=document.createElement('strong'),u=document.createElement('small');l.textContent=label;v.textContent=value;u.textContent=unit;$('trace-result').append(l,v,u);}
function renderTerms(items) {
  const container=$('contribution-list');container.replaceChildren();
  for(const item of items.slice(0,6)) {const button=document.createElement('button');button.type='button';button.className='term'+(item.id===activeNeighbor?' is-active':'');button.dataset.neighbor=item.id;button.textContent=(item.id===selected?'自身':'j'+item.id)+' '+fmt(item.value,1);button.title='密度贡献 '+fmt(item.value,3)+' kg/m³';container.append(button);}
  if(items.length>6){const rest=document.createElement('span');rest.className='term-rest';rest.textContent='+ 其余 '+(items.length-6)+' 项';container.append(rest);}
}
function renderTrace(items) {
  const p=particles[selected],rho=fields.rho[selected],pressure=fields.pressure[selected],info=stageInfo[stage];
  set('trace-title',info.title);set('trace-description',info.desc);set('trace-index',String(Object.keys(stageInfo).indexOf(stage)+1).padStart(2,'0')+' / 05');
  set('view-label',info.view);$('color-key').querySelector('span').textContent=info.key;$('trace-reference').href='#'+info.ref;
  $('trace-chart').setAttribute('aria-label',info.title);
  if($('trace-formula').dataset.stage!==stage){$('trace-formula').replaceChildren($('formula-'+stage).content.cloneNode(true));$('trace-formula').dataset.stage=stage;}
  $('contribution-list').replaceChildren();
  const active=items.find(v=>v.id===activeNeighbor)||items[0];
  if(stage==='particles'||stage==='kernel') {
    const c=chartBase(0,config.h*2,kernel2D(0,config.h)*1.12,'距离 r / m','核权重 W / m⁻²');
    drawCurve(c,r=>kernel2D(r,config.h),0,2*config.h);
    for(const term of items)c.chart.append(svgNode('circle',{cx:c.x(term.r),cy:c.y(term.weight),r:term.id===activeNeighbor?5:2.5,fill:term.id===activeNeighbor?'#b97c3f':'#74a08a',opacity:term.id===activeNeighbor?1:.4,'data-neighbor':term.id}));
    c.chart.append(svgNode('line',{x1:c.x(active.r),x2:c.x(active.r),y1:145,y2:c.y(active.weight),class:'plot-guide'}));
    result('邻居 j = '+active.id,fmt(active.value,2),'kg/m³');
    renderTerms(items);
    set('trace-insight',`距离 ${fmt(active.r*1000,1)} mm → 权重 ${fmt(active.weight,2)} m⁻² → 贡献 ${fmt(active.value,2)} kg/m³。每个粒子质量为 ${fmt(MASS,3)} kg，切片厚度 1 m。`);
  } else if(stage==='density') {
    const chart=$('trace-chart');chart.replaceChildren();
    chart.append(svgNode('text',{x:8,y:25,class:'plot-title'},'每段 = 一个粒子的密度贡献'));
    let offset=10;
    items.forEach((term,i)=>{const w=420*term.value/rho;chart.append(svgNode('rect',{x:offset,y:52,width:Math.max(.1,w-.7),height:55,rx:1,fill:term.id===activeNeighbor?'#b97c3f':mixColor(.3+.7*(1-i/items.length)),'data-neighbor':term.id,style:'cursor:pointer'}));offset+=w;});
    chart.append(svgNode('line',{x1:10,x2:430,y1:122,y2:122,class:'plot-axis'}),svgNode('text',{x:10,y:145,class:'plot-label'},'0'),svgNode('text',{x:430,y:145,'text-anchor':'end',class:'plot-label'},fmt(rho,1)+' kg/m³'),svgNode('text',{x:10,y:177,class:'plot-label'},'质量 × 核权重 ÷ 切片厚度 → 密度'));
    result('ρᵢ',fmt(rho,2),'kg/m³');renderTerms(items);
    const self=items.find(v=>v.id===selected).value;
    set('trace-insight',`自身 ${fmt(self,1)} + 邻居 ${fmt(rho-self,1)} = ${fmt(rho,1)} kg/m³。相对参考密度偏差为 ${rho>=RHO0?'+':''}${fmt((rho/RHO0-1)*100,2)}%。边缘粒子的邻域不完整，会低估密度。`);
  } else if(stage==='pressure') {
    const xmin=Math.min(900,Math.floor(rho/50)*50-25),xmax=Math.max(1150,Math.ceil(rho/50)*50+25);
    const f=r=>Math.max(0,RHO0*config.cs**2/config.gamma*((r/RHO0)**config.gamma-1))/1000;
    const ymax=Math.max(10,f(xmax)*1.05),c=chartBase(xmin,xmax,ymax,'密度 ρ / kg·m⁻³','压力 p / kPa');
    drawCurve(c,f,xmin,xmax);drawCurve(c,r=>Math.max(0,config.cs**2*(r-RHO0))/1000,xmin,xmax,{stroke:'#9aaab1','stroke-dasharray':'4 4','stroke-width':1.2});
    c.chart.append(svgNode('line',{x1:c.x(rho),x2:c.x(rho),y1:145,y2:c.y(pressure/1000),class:'plot-guide'}),svgNode('circle',{cx:c.x(rho),cy:c.y(pressure/1000),r:5,class:'plot-point'}));
    result('pᵢ',fmt(pressure/1000,2),'kPa');
    const legend=document.createElement('span');legend.className='term-rest';legend.textContent='实线 Tait · 虚线 线性近似 · 纵轴随声速缩放';$('contribution-list').append(legend);
    set('trace-insight',`ρᵢ = ${fmt(rho,1)} kg/m³。${fields.rawPressure[selected]<0?'原始 Tait 压力为 '+fmt(fields.rawPressure[selected]/1000,2)+' kPa，演示截断为零。':'同样的密度偏差，声速加倍，压力变为四倍。'} 实际推进同时使用相邻粒子的压力，均匀高压并不等于局部合力很大。`);
  } else {
    const chart=$('trace-chart');chart.replaceChildren();const max=Math.max(...fields.limits.filter(v=>Number.isFinite(v.value)).map(v=>v.value));
    fields.limits.forEach((v,i)=>{
      const y=22+i*48,limiting=v.name===fields.limiting;
      chart.append(svgNode('text',{x:8,y,class:'plot-title'},v.name+(limiting?' · 当前限制':'')),svgNode('text',{x:430,y,'text-anchor':'end',class:'plot-label'},Number.isFinite(v.value)?fmt(v.value*1000,3)+' ms':'未启用'));
      chart.append(svgNode('rect',{x:8,y:y+10,width:422,height:5,rx:2,fill:'#dde6dc'}));
      if(Number.isFinite(v.value))chart.append(svgNode('rect',{x:8,y:y+10,width:Math.max(2,422*v.value/max),height:5,rx:2,fill:limiting?'#b97c3f':'#83aa94'}));
    });
    chart.append(svgNode('text',{x:8,y:180,class:'plot-label'},'取最小上限 · 表面张力关闭'));
    result('下一步 Δt',fmt(fields.dt*1000,3),'ms');
    const a=fields.acceleration[selected],speed=Math.hypot(p.vx,p.vy);
    const detail=document.createElement('span');detail.className='term-rest';detail.textContent='|aᵢ| = '+fmt(Math.hypot(a.x,a.y),1)+' m/s² · |vᵢ| = '+fmt(speed,3)+' m/s';$('contribution-list').append(detail);
    set('trace-insight',lastStep?`上一步推进 ${fmt(lastStep.dt*1000,3)} ms；粒子移动 ${fmt(lastStep.distance*1000,4)} mm。当前显示更新后重新计算的场。声学上限使用当前 Tait 声速。`:'点击「步进」执行一次半隐式 Euler 更新。播放按每帧一步慢放，累计时间按实际 Δt 计算；不以视觉播放速度替代物理时间。');
  }
}
function render() {
  const items=renderScene();renderTrace(items);
  document.querySelectorAll('[data-stage]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.stage===stage)));
  document.querySelectorAll('[data-scene]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.scene===scene)));
  set('pipeline-particles','i = '+selected);set('pipeline-kernel',items.length+' 项贡献');set('pipeline-density',fmt(fields.rho[selected],1)+' kg/m³');set('pipeline-pressure',fmt(fields.pressure[selected]/1000,2)+' kPa');set('pipeline-integrate',fmt(fields.dt*1000,3)+' ms');
  set('param-h-value',fmt(config.h*1000,2)+' mm');set('param-cs-value',config.cs+' m/s');set('param-gamma-value',config.gamma);set('param-nu-value',fmt(config.nu*1e6,0)+' mm²/s');
  set('simulation-time','t = '+fmt(time*1000,2)+' ms');set('experiment-status',(running?'播放中 · 每帧一步':'已暂停 · 可自由探索')+' · '+steps+' 步');
  $('play').textContent=running?'Ⅱ 暂停':'▶ 播放';$('play').setAttribute('aria-pressed',String(running));
}
function recalculate(){fields=compute(particles,config);render();}
function pause(){running=false;cancelAnimationFrame(raf);raf=0;}
function setStage(value){stage=value;render();}
function setScene(value,resetParams=false) {
  pause();scene=value;
  if(resetParams){Object.assign(config,{h:DEFAULT_H,cs:20,gamma:7,nu:0});for(const [key,scale]of [['h',1000],['cs',1],['gamma',1],['nu',1e6]])$('param-'+key).value=config[key]*scale;}
  particles=makeParticles(scene);ghosts=particles.map(p=>({...p}));time=0;steps=0;lastStep=null;trace=[];recalculate();
}
function selectParticle(id){selected=id;activeNeighbor=id;trace=[];render();}
function moveSelected(x,y) {pause();particles[selected]={...particles[selected],x:Math.max(.025,Math.min(.975,x)),y:Math.max(.025,Math.min(.975,y)),vx:0,vy:0};trace=[];lastStep=null;recalculate();}
function stepForward() {
  const before=particles[selected],next=advance(particles,config,fields);
  particles=next.particles;time+=next.dt;steps++;
  lastStep={dt:next.dt,distance:Math.hypot(particles[selected].x-before.x,particles[selected].y-before.y)};
  trace.push({x:particles[selected].x,y:particles[selected].y});if(trace.length>240)trace.shift();
  fields=compute(particles,config);
}
function tick(){if(!running)return;stepForward();render();raf=requestAnimationFrame(tick);}
function play(){running=true;raf=requestAnimationFrame(tick);render();}
document.querySelectorAll('[data-stage]').forEach(b=>b.addEventListener('click',()=>setStage(b.dataset.stage)));
document.querySelectorAll('[data-explore]').forEach(b=>b.addEventListener('click',()=>{pause();setStage(b.dataset.explore);}));
document.querySelectorAll('[data-scene]').forEach(b=>b.addEventListener('click',()=>setScene(b.dataset.scene)));
$('reset').addEventListener('click',()=>setScene(scene,true));
$('play').addEventListener('click',()=>{if(running){pause();render();}else play();});
$('single-step').addEventListener('click',()=>{pause();stage='integrate';stepForward();render();});
$('selected-particle').addEventListener('change',e=>{const v=Number(e.target.value);if(Number.isInteger(v)&&v>=0&&v<121){pause();selectParticle(v);}else e.target.value=selected;});
for(const [key,scale]of [['h',.001],['cs',1],['gamma',1],['nu',1e-6]])$('param-'+key).addEventListener('input',e=>{pause();config[key]=Number(e.target.value)*scale;recalculate();});
function setNeighbor(id){if(contributions(particles,selected,config.h).some(v=>v.id===id)){activeNeighbor=id;render();}}
$('contribution-list').addEventListener('click',e=>{const id=e.target.closest('[data-neighbor]')?.dataset.neighbor;if(id!==undefined){setNeighbor(Number(id));$('contribution-list').querySelector('[data-neighbor="'+id+'"]')?.focus({preventScroll:true});}});
$('trace-chart').addEventListener('click',e=>{const id=e.target.closest('[data-neighbor]')?.dataset.neighbor;if(id!==undefined)setNeighbor(Number(id));});
canvas.addEventListener('pointerdown',e=>{
  const target=e.target.closest('[data-particle]');if(!target)return;e.preventDefault();pause();selected=Number(target.dataset.particle);activeNeighbor=selected;trace=[];dragging=true;canvas.setPointerCapture(e.pointerId);render();dots[selected].focus({preventScroll:true});
});
canvas.addEventListener('pointermove',e=>{
  if(dragging){const matrix=canvas.getScreenCTM();if(!matrix)return;const point=new DOMPoint(e.clientX,e.clientY).matrixTransform(matrix.inverse());moveSelected((point.x-100)/460,1-(point.y-25)/460);}
  else if(!running){const id=e.target.closest('[data-particle]')?.dataset.particle;if(id!==undefined&&Number(id)!==activeNeighbor)setNeighbor(Number(id));}
});
const stopDrag=()=>{dragging=false;};canvas.addEventListener('pointerup',stopDrag);canvas.addEventListener('pointercancel',stopDrag);canvas.addEventListener('lostpointercapture',stopDrag);
canvas.addEventListener('keydown',e=>{const d={ArrowLeft:[-.005,0],ArrowRight:[.005,0],ArrowUp:[0,.005],ArrowDown:[0,-.005]}[e.key];if(d){e.preventDefault();const p=particles[selected];moveSelected(p.x+d[0],p.y+d[1]);}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();render();}});
new IntersectionObserver(entries=>{if(!entries[0].isIntersecting&&running){pause();render();}},{threshold:0}).observe($('explorer'));
// Agent actions share the exact state transitions used by the visible controls.
function snapshot(){const p=particles[selected];return {scene,stage,selected,position:{x:p.x,y:p.y},parameters:{...config},density:fields.rho[selected],pressure:fields.pressure[selected],neighbor:activeNeighbor,contributions:contributions(particles,selected,config.h).length,time,steps,dt:fields.dt,limiting:fields.limiting,running,lastStep};}
if(document.modelContext?.registerTool){
 const lifecycle=new AbortController();
 const register=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}};
 register({name:'configure_wcsph_explorer',title:'探索粒子计算链',description:'Select a stage, scene or particle, move the particle, or adjust simulation parameters; pauses playback. Returns the same numerical state shown on the page.',inputSchema:{type:'object',properties:{stage:{type:'string',enum:Object.keys(stageInfo)},scene:{type:'string',enum:['rest','compressed','disturbed']},particle:{type:'integer',minimum:0,maximum:120},position:{type:'object',properties:{x:{type:'number'},y:{type:'number'}},required:['x','y'],additionalProperties:false},parameters:{type:'object',properties:{h:{type:'number'},cs:{type:'number'},gamma:{type:'number'},nu:{type:'number'}},additionalProperties:false},neighbor:{type:'integer',minimum:0,maximum:120}},additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){
   if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid input');
   for(const key of Object.keys(input))if(!['stage','scene','particle','position','parameters','neighbor'].includes(key))throw Error('Unknown field '+key);
   if(input.stage!==undefined&&!Object.hasOwn(stageInfo,input.stage))throw Error('Invalid stage');
   if(input.scene!==undefined&&!['rest','compressed','disturbed'].includes(input.scene))throw Error('Invalid scene');
   for(const key of ['particle','neighbor'])if(input[key]!==undefined&&(!Number.isInteger(input[key])||input[key]<0||input[key]>120))throw Error('Invalid particle');
   if(input.position!==undefined){if(!input.position||Array.isArray(input.position)||Object.keys(input.position).length!==2)throw Error('Invalid position');for(const key of ['x','y'])if(!Number.isFinite(input.position[key])||input.position[key]<.025||input.position[key]>.975)throw Error('Position out of range');}
   const ranges={h:[.07,.13],cs:[10,60],gamma:[1,9],nu:[0,.005]};
   if(input.parameters!==undefined){if(!input.parameters||typeof input.parameters!=='object'||Array.isArray(input.parameters))throw Error('Invalid parameters');for(const [key,v]of Object.entries(input.parameters))if(!Object.hasOwn(ranges,key)||!Number.isFinite(v)||v<ranges[key][0]||v>ranges[key][1])throw Error('Parameter out of range: '+key);}
   pause();
   if(input.scene!==undefined)setScene(input.scene);
   if(input.stage!==undefined)stage=input.stage;
   if(input.particle!==undefined){selected=input.particle;trace=[];}
   if(input.parameters)for(const [key,v]of Object.entries(input.parameters)){const scale={h:1000,cs:1,gamma:1,nu:1e6}[key];const field=$('param-'+key);field.value=v*scale;config[key]=Number(field.value)/scale;}
   if(input.position)particles[selected]={...particles[selected],...input.position,vx:0,vy:0};
   if(input.neighbor!==undefined)activeNeighbor=input.neighbor;
   recalculate();return snapshot();
 }});
 register({name:'advance_wcsph_simulation',title:'推进 WCSPH 模拟',description:'Advance the visible simulation by 1 to 100 actual adaptive time steps and show the integration stage. Pauses playback.',inputSchema:{type:'object',properties:{steps:{type:'integer',minimum:1,maximum:100}},required:['steps'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){if(!input||Object.keys(input).some(k=>k!=='steps')||!Number.isInteger(input.steps)||input.steps<1||input.steps>100)throw Error('Steps must be an integer from 1 to 100');pause();stage='integrate';for(let i=0;i<input.steps;i++)stepForward();render();return snapshot();}});
 addEventListener('pagehide',()=>{pause();lifecycle.abort();},{once:true});
}
render();
