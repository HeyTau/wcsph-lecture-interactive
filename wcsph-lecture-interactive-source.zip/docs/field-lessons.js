import {FIELD_LENGTH,wrapUnit,referenceField,makeSamples,reconstructField,temperatureField,materialState} from './field-models.mjs';
const flEl=id=>document.getElementById(id),flFormat=(n,d=3)=>n===null?'未定义':Number(n).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const flText=(id,text)=>{flEl(id).textContent=text;};
function flNode(tag,attrs={},text){const node=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v]of Object.entries(attrs))node.setAttribute(k,String(v));if(text!==undefined)node.textContent=text;return node;}
function flAxes(svg,{w=820,height=330,xmax=1,ymin=0,ymax=2.2,xlabel='x / m',ylabel='场值 A'}={}){
  svg.replaceChildren();const left=46,right=w-20,top=25,bottom=height-45,x=v=>left+v/xmax*(right-left),y=v=>bottom-(v-ymin)/(ymax-ymin)*(bottom-top);
  for(let i=0;i<=4;i++){const val=ymin+(ymax-ymin)*i/4;svg.append(flNode('line',{x1:left,x2:right,y1:y(val),y2:y(val),class:'fl-plot-grid'}),flNode('text',{x:left-8,y:y(val)+4,'text-anchor':'end',class:'fl-plot-text'},flFormat(val,ymax>10?0:1)));}
  for(let i=0;i<=4;i++){const v=xmax*i/4;svg.append(flNode('text',{x:x(v),y:bottom+20,'text-anchor':'middle',class:'fl-plot-text'},flFormat(v,xmax>1?1:2)));}
  svg.append(flNode('text',{x:left,y:14,class:'fl-plot-label'},ylabel),flNode('text',{x:right,y:height-4,'text-anchor':'end',class:'fl-plot-label'},xlabel));
  return {svg,x,y,left,right,top,bottom,xmax};
}
function flLine(chart,fn,{color='#438d67',width=2.5,dash='',opacity=1,lo=0,hi=chart.xmax,steps=200,...extra}={}){
  let path='',open=false;
  for(let i=0;i<=steps;i++){const x=lo+(hi-lo)*i/steps,v=fn(x);if(v===null||!Number.isFinite(v)){open=false;continue;}path+=(open?'L':'M')+chart.x(x).toFixed(2)+','+chart.y(v).toFixed(2);open=true;}
  const n=flNode('path',{d:path,fill:'none',stroke:color,'stroke-width':width,'stroke-dasharray':dash,opacity,...extra});chart.svg.append(n);return n;
}
let reconstruction={shape:'wave',n:15,h:.09,query:.5,normalized:false,layer:'sum',selected:7};
let samples=makeSamples(reconstruction.n,reconstruction.shape),edited=false,reconstructionChart=null,fieldDrag=null;
function reconstructionState(){
 const state=reconstructField(samples,reconstruction.query,reconstruction.h,reconstruction.normalized);
 return {shape:reconstruction.shape,n:reconstruction.n,h:reconstruction.h,query:reconstruction.query,normalized:reconstruction.normalized,layer:reconstruction.layer,selected:reconstruction.selected,sample:{...samples[reconstruction.selected]},value:state.value,reference:referenceField(reconstruction.query,reconstruction.shape),partition:state.partition,supported:state.supported,neighbors:state.terms.filter(v=>v.weight>0).length,selectedContribution:state.terms[reconstruction.selected].contribution};
}
function renderReconstruction(){
 const r=reconstruction,now=reconstructField(samples,r.query,r.h,r.normalized);
 const grid=Array.from({length:241},(_,i)=>{const x=i/240;return {x,...reconstructField(samples,x,r.h,r.normalized)};});
 const ymax=Math.max(2.2,Math.ceil(Math.max(...samples.map(p=>p.value),...grid.map(v=>v.value??0))*1.15*5)/5);
 const svg=flEl('reconstruction-chart'),chart=flAxes(svg,{ymax});reconstructionChart=chart;
 const selectedSample=samples[r.selected];
 const supportWidth=2*r.h;
 // The support of the selected sample wraps across the periodic boundary.
 for(const center of [selectedSample.x-1,selectedSample.x,selectedSample.x+1]){
   const a=Math.max(0,center-supportWidth),b=Math.min(1,center+supportWidth);
   if(a<b&&r.layer!=='samples')svg.append(flNode('rect',{x:chart.x(a),y:chart.top,width:chart.x(b)-chart.x(a),height:chart.bottom-chart.top,fill:'#c8ddc0',opacity:.2}));
 }
 flLine(chart,x=>referenceField(x,r.shape),{color:'#98a99a',width:1.7,dash:'4 5'});
 if(r.layer==='kernels')for(const p of samples)if(p.id!==r.selected)flLine(chart,x=>reconstructField(samples,x,r.h,r.normalized).terms[p.id].contribution,{color:'#80aa7c',width:1,opacity:.4,steps:140});
 if(r.layer!=='samples')flLine(chart,x=>reconstructField(samples,x,r.h,r.normalized).terms[r.selected].contribution,{color:'#bd8149',width:2,steps:240});
 if(r.layer==='sum')flLine(chart,x=>reconstructField(samples,x,r.h,r.normalized).value,{color:'#3b8b60',width:2.8,steps:360});
 svg.append(flNode('line',{x1:chart.x(r.query),x2:chart.x(r.query),y1:chart.top,y2:chart.bottom,stroke:'#82a587','stroke-dasharray':'3 5'}));
 if(now.value!==null&&r.layer==='sum')svg.append(flNode('circle',{cx:chart.x(r.query),cy:chart.y(now.value),r:5,fill:'#3c8860',stroke:'#f5f7f3','stroke-width':2}));
 for(const p of samples){
  const group=flNode('g',{transform:`translate(${chart.x(p.x)},${chart.y(p.value)})`,class:'fl-sample-point','data-field-particle':p.id,role:'button',tabindex:p.id===r.selected?0:-1,'aria-pressed':String(p.id===r.selected),'aria-label':`采样粒子 ${p.id}，位置 ${flFormat(p.x)}，场值 ${flFormat(p.value)}`});
  group.append(flNode('circle',{r:12,fill:'transparent'}),flNode('circle',{r:p.id===r.selected?6:4.2,fill:p.id===r.selected?'#bb7e45':'#6d9476',stroke:'#f5f7f3','stroke-width':1.5}));
  if(p.id===r.selected)group.append(flNode('text',{x:10,y:-11,class:'fl-plot-text',fill:'#aa713c'},'j = '+p.id));svg.append(group);
 }
 const probe=flNode('g',{class:'fl-probe','data-field-probe':'true',role:'slider',tabindex:0,'aria-label':'查询位置游标','aria-valuemin':0,'aria-valuemax':1,'aria-valuenow':r.query,transform:`translate(${chart.x(r.query)},${chart.bottom+1})`});
 probe.append(flNode('rect',{x:-12,y:-5,width:24,height:23,fill:'transparent'}),flNode('path',{d:'M0,0 L-6,10 L6,10 Z',fill:'#438b63'}));svg.append(probe);
 flText('reconstruction-query',flFormat(r.query));flText('reconstruction-value',flFormat(now.value));flText('reconstruction-reference',flFormat(referenceField(r.query,r.shape)));flText('reconstruction-partition',flFormat(now.partition));
 for(const [key,id,d]of [['n','count',0],['h','h',3],['query','probe',3]]){flEl('reconstruction-'+id).value=r[key];flText('reconstruction-'+id+'-value',flFormat(r[key],d)+(key==='n'?'':' m'));}
 flEl('reconstruction-sample').value=selectedSample.value;flText('reconstruction-sample-value',flFormat(selectedSample.value,2));
 flEl('reconstruction-selected').max=r.n-1;flEl('reconstruction-selected').value=r.selected;flEl('reconstruction-shape').value=r.shape;flEl('reconstruction-normalized').checked=r.normalized;
 document.querySelectorAll('[data-reconstruction-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.reconstructionLayer===r.layer)));
 const formula=flEl('reconstruction-formula'),mode=String(r.normalized);
 if(formula.dataset.normalized!==mode){formula.replaceChildren(flEl(r.normalized?'reconstruction-normal-template':'reconstruction-raw-template').content.cloneNode(true));formula.dataset.normalized=mode;}
 const term=now.terms[r.selected],numerator=flFormat(term.sample,2)+' × '+flFormat(term.volume,3)+' × '+flFormat(term.kernel,2);
 flText('reconstruction-term',numerator+(r.normalized?' ÷ '+flFormat(now.partition,3):'')+' = '+flFormat(term.contribution));
 const list=flEl('reconstruction-terms');list.replaceChildren();
 const contributors=now.terms.filter(v=>v.weight>1e-9||v.id===r.selected).sort((a,b)=>b.raw-a.raw);
 const shown=contributors.slice(0,9);if(!shown.some(t=>t.id===r.selected)){shown.pop();shown.push(term);}
 for(const t of shown){const button=document.createElement('button');button.type='button';button.dataset.fieldTerm=t.id;button.setAttribute('aria-pressed',String(t.id===r.selected));button.textContent='j'+t.id+' · '+flFormat(t.contribution);list.append(button);}
 if(contributors.length>9){const span=document.createElement('span');span.textContent='+ 其余 '+(contributors.length-9)+' 项';list.append(span);}
 let insight;
 if(!now.supported)insight=r.normalized?'查询位置没有粒子落在核支撑域内，分母为 0，归一化重建未定义。增加 h 或增加粒子数量，让邻域覆盖这里。':'查询位置没有邻居，原始粒子求和为 0。缩小 h 不一定更准确：粒子间的空隙可能失去覆盖。';
 else if(r.shape==='constant'&&r.normalized&&!edited)insight='常数场 Aⱼ = 1。归一化后，分子与分母相同，只要存在邻居，就能精确重建常数。关闭归一化可观察离散权重之和的偏差。';
 else insight=`当前位置有 ${now.terms.filter(t=>t.weight>0).length} 项非零贡献。${edited?'采样值已被你修改，灰色参考场保持不变。':'增大 h 会让更多粒子参与、同时抹平局部细节；过小的 h 可能留下空隙。'} ${r.normalized?'当前将原始求和除以权重之和。':'原始求和要求离散权重之和接近 1；核的连续归一化不保证离散求和恰好为 1。'}`;
 flText('reconstruction-insight',insight);
}
function particleBounds(points,id){return [id===0?.002:points[id-1].x+.004,id===points.length-1?.998:points[id+1].x-.004];}
function changeReconstruction(input={}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid reconstruction input');
 const allowed=['shape','n','h','query','normalized','layer','particle','reset','resample'];
 for(const key of Object.keys(input))if(!allowed.includes(key))throw Error('Unknown field '+key);
 if(input.shape!==undefined&&!['wave','bump','constant'].includes(input.shape))throw Error('Unknown reference field');
 if(input.n!==undefined&&(!Number.isInteger(input.n)||input.n<7||input.n>31||input.n%2!==1))throw Error('Particle count must be an odd integer from 7 to 31');
 for(const [key,a,b]of [['h',.025,.18],['query',0,1]])if(input[key]!==undefined&&(!Number.isFinite(input[key])||input[key]<a||input[key]>b))throw Error('Out of range: '+key);
 for(const key of ['normalized','reset','resample'])if(input[key]!==undefined&&typeof input[key]!=='boolean')throw Error('Expected boolean: '+key);
 if(input.layer!==undefined&&!['samples','kernels','sum'].includes(input.layer))throw Error('Unknown layer');
 const base=input.reset?{shape:'wave',n:15,h:.09,query:.5,normalized:false,layer:'sum',selected:7}:{...reconstruction};
 const next={...base};for(const k of ['shape','n','h','query','normalized','layer'])if(input[k]!==undefined)next[k]=input[k];
 const fresh=input.reset||input.resample||input.shape!==undefined||input.n!==undefined;
 const nextSamples=fresh?makeSamples(next.n,next.shape):samples.map(p=>({...p}));next.selected=Math.min(next.selected,next.n-1);
 if(input.particle!==undefined){
   const p=input.particle;if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['id','x','value'].includes(k))||!Number.isInteger(p.id)||p.id<0||p.id>=next.n)throw Error('Invalid particle');
   const [lo,hi]=particleBounds(nextSamples,p.id);
   if(p.x!==undefined&&(!Number.isFinite(p.x)||p.x<lo||p.x>hi))throw Error('Particle position must remain between its neighbors');
   if(p.value!==undefined&&(!Number.isFinite(p.value)||p.value<0||p.value>2.5))throw Error('Particle value must be between 0 and 2.5');
   next.selected=p.id;if(p.x!==undefined)nextSamples[p.id].x=p.x;if(p.value!==undefined)nextSamples[p.id].value=p.value;
 }
 reconstruction=next;samples=nextSamples;if(fresh)edited=false;if(input.particle&&(input.particle.x!==undefined||input.particle.value!==undefined))edited=true;
 renderReconstruction();return reconstructionState();
}
for(const [id,key]of [['count','n'],['h','h'],['probe','query']])flEl('reconstruction-'+id).addEventListener('input',e=>changeReconstruction({[key]:Number(e.target.value)}));
flEl('reconstruction-sample').addEventListener('input',e=>changeReconstruction({particle:{id:reconstruction.selected,value:Number(e.target.value)}}));
flEl('reconstruction-selected').addEventListener('change',e=>{try{changeReconstruction({particle:{id:Number(e.target.value)}});}catch{e.target.value=reconstruction.selected;}});
flEl('reconstruction-shape').addEventListener('change',e=>changeReconstruction({shape:e.target.value}));
flEl('reconstruction-normalized').addEventListener('change',e=>changeReconstruction({normalized:e.target.checked}));
flEl('reconstruction-reset').addEventListener('click',()=>changeReconstruction({reset:true}));
flEl('reconstruction-resample').addEventListener('click',()=>changeReconstruction({resample:true}));
document.querySelectorAll('[data-reconstruction-layer]').forEach(b=>b.addEventListener('click',()=>changeReconstruction({layer:b.dataset.reconstructionLayer})));
flEl('reconstruction-terms').addEventListener('click',e=>{const id=e.target.closest('[data-field-term]')?.dataset.fieldTerm;if(id!==undefined){changeReconstruction({particle:{id:Number(id)}});flEl('reconstruction-terms').querySelector('[data-field-term="'+id+'"]')?.focus({preventScroll:true});}});
const fieldSVG=flEl('reconstruction-chart');
fieldSVG.addEventListener('pointerdown',e=>{
 const particle=e.target.closest('[data-field-particle]'),probe=e.target.closest('[data-field-probe]');if(!particle&&!probe)return;
 e.preventDefault();fieldDrag=particle?{id:Number(particle.dataset.fieldParticle)}:{probe:true};fieldSVG.setPointerCapture(e.pointerId);
 if(particle)changeReconstruction({particle:{id:fieldDrag.id}});
});
fieldSVG.addEventListener('pointermove',e=>{
 if(!fieldDrag)return;const c=reconstructionChart,pt=new DOMPoint(e.clientX,e.clientY).matrixTransform(fieldSVG.getScreenCTM().inverse());
 const x=(pt.x-c.left)/(c.right-c.left);
 if(fieldDrag.probe)changeReconstruction({query:Math.max(0,Math.min(1,x))});
 else{const [lo,hi]=particleBounds(samples,fieldDrag.id);const yAtZero=c.y(0),yAtOne=c.y(1);const value=(pt.y-yAtZero)/(yAtOne-yAtZero);changeReconstruction({particle:{id:fieldDrag.id,x:Math.max(lo,Math.min(hi,x)),value:Math.max(0,Math.min(2.5,value))}});}
});
for(const event of ['pointerup','pointercancel','lostpointercapture'])fieldSVG.addEventListener(event,()=>{fieldDrag=null;});
fieldSVG.addEventListener('keydown',e=>{
 const delta={ArrowLeft:[-.005,0],ArrowRight:[.005,0],ArrowUp:[0,.02],ArrowDown:[0,-.02]}[e.key];if(!delta)return;
 const probe=e.target.closest('[data-field-probe]'),point=e.target.closest('[data-field-particle]');if(!probe&&!point)return;e.preventDefault();
 if(probe){changeReconstruction({query:Math.max(0,Math.min(1,reconstruction.query+(delta[0]||delta[1]/4)))});fieldSVG.querySelector('[data-field-probe]')?.focus({preventScroll:true});}
 else{const id=Number(point.dataset.fieldParticle),p=samples[id],[lo,hi]=particleBounds(samples,id);changeReconstruction({particle:{id,x:Math.max(lo,Math.min(hi,p.x+delta[0])),value:Math.max(0,Math.min(2.5,p.value+delta[1]))}});fieldSVG.querySelector('[data-field-particle="'+id+'"]')?.focus({preventScroll:true});}
});

const materialPresets={static:{u:1,c:0,source:0,x0:1.2},follow:{u:1,c:1,source:0,x0:1.2},heating:{u:0,c:0,source:1,x0:1.2}};
let material={...materialPresets.static,time:0},materialPlaying=false,materialFrame=0,materialLast=0,materialDragging=false,materialSpaceChart=null;
function materialSnapshot(){return {...material,...materialState(material),playing:materialPlaying};}
function renderMaterial(){
 const m=material,s=materialState(m);
 const space=flAxes(flEl('material-space'),{w:410,height:275,xmax:10,ymin:0,ymax:40,xlabel:'位置 x / m',ylabel:'T / °C'});materialSpaceChart=space;
 // A continuous color strip encodes the same analytic temperature as the curve.
 for(let i=0;i<100;i++){const x=i/10,temp=temperatureField(x,m.time,m),f=Math.max(0,Math.min(1,temp/40));space.svg.append(flNode('rect',{x:space.x(x),y:space.bottom-10,width:(space.right-space.left)/100+.2,height:10,fill:`hsl(${190-150*f} 35% ${88-27*f}%)`,opacity:.75}));}
 flLine(space,x=>temperatureField(x,m.time,m),{color:'#88a985',width:2.4});
 space.svg.append(flNode('line',{x1:space.x(m.x0),x2:space.x(m.x0),y1:space.bottom,y2:space.y(s.fixedTemperature),stroke:'#5b80a9','stroke-dasharray':'3 4'}));
 const fixed=flNode('g',{class:'fl-probe','data-material-origin':'true',role:'slider',tabindex:0,'aria-label':'拖动固定测点以设置共同起点','aria-valuemin':0,'aria-valuemax':9.9,'aria-valuenow':m.x0});
 fixed.append(flNode('rect',{x:space.x(m.x0)-12,y:space.y(s.fixedTemperature)-12,width:24,height:24,fill:'transparent'}),flNode('rect',{x:space.x(m.x0)-5,y:space.y(s.fixedTemperature)-5,width:10,height:10,fill:'#5b80a9',stroke:'#f5f7f3','stroke-width':1.5}),flNode('rect',{x:space.x(m.x0)-12,y:space.bottom+2,width:24,height:15,fill:'transparent'}),flNode('rect',{x:space.x(m.x0)-5,y:space.bottom+5,width:10,height:9,rx:1,fill:'#5b80a9'}));space.svg.append(fixed);
 space.svg.append(flNode('line',{x1:space.x(s.x),x2:space.x(s.x),y1:space.bottom,y2:space.y(s.temperature),stroke:'#4b9669','stroke-dasharray':'3 4'}),flNode('circle',{cx:space.x(s.x),cy:space.y(s.temperature),r:7,fill:'#43895d',stroke:'#f5f7f3','stroke-width':2}));
 if(Math.abs(s.x-m.x0)<.15)space.svg.append(flNode('circle',{cx:space.x(s.x),cy:space.y(s.temperature),r:10,fill:'none',stroke:'#5b80a9','stroke-width':1.5}));
 const labelX=Math.max(space.left+50,Math.min(space.right-55,space.x(s.x)));
 space.svg.append(flNode('text',{x:labelX,y:space.y(s.temperature)-16,'text-anchor':'middle',class:'fl-plot-text',fill:'#3f8259'},'粒子 '+flFormat(s.temperature,1)+'°C'));
 if(Math.abs(m.u)>.001){const y=space.bottom-21,x=space.x(s.x),end=Math.max(space.left,Math.min(space.right,x+Math.sign(m.u)*24));space.svg.append(flNode('path',{d:`M${x},${y} L${end},${y} m${-Math.sign(m.u)*5},-3 l${Math.sign(m.u)*5},3 l${-Math.sign(m.u)*5},3`,stroke:'#43895d',fill:'none','stroke-width':1.5}));}
 const history=flAxes(flEl('material-history'),{w:410,height:275,xmax:6,ymin:0,ymax:40,xlabel:'时间 t / s',ylabel:'T / °C'});
 const fixedT=t=>temperatureField(m.x0,t,m),movingT=t=>temperatureField(m.x0+m.u*t,t,m);
 flLine(history,fixedT,{color:'#5b80a9',width:1.7,opacity:.25,dash:'3 4'});flLine(history,movingT,{color:'#43895d',width:1.7,opacity:.25,dash:'3 4'});
 if(m.time>0){flLine(history,fixedT,{color:'#5b80a9',width:2.2,hi:m.time});flLine(history,movingT,{color:'#43895d',width:2.5,hi:m.time});}
 history.svg.append(flNode('line',{x1:history.x(m.time),x2:history.x(m.time),y1:history.top,y2:history.bottom,stroke:'#b0c1aa','stroke-dasharray':'3 4'}),flNode('rect',{x:history.x(m.time)-4,y:history.y(s.fixedTemperature)-4,width:8,height:8,fill:'#5b80a9'}),flNode('circle',{cx:history.x(m.time),cy:history.y(s.temperature),r:5,fill:'#43895d',stroke:'#f5f7f3','stroke-width':1.5}));
 // Tangent of the material temperature history, using the analytic total derivative.
 const dt=.28,lo=Math.max(0,m.time-dt),hi=Math.min(6,m.time+dt);
 flLine(history,t=>s.temperature+s.total*(t-m.time),{lo,hi,color:'#b88147',width:1.5,steps:2});
 for(const [key,id,unit,d]of [['u','u','m/s',1],['c','c','m/s',1],['source','source','°C/s',1],['x0','x0','m',1],['time','time','s',2]]){flEl('material-'+id).value=m[key];flText('material-'+id+'-value',flFormat(m[key],d)+' '+unit);}
 for(const key of ['local','advection','total'])flText('material-'+key,(s[key]>0?'+':'')+flFormat(Math.abs(s[key])<5e-10?0:s[key],3));
 flText('material-clock','t = '+flFormat(m.time,2)+' s');flText('material-location',`三个导数项均取在粒子当前 x = ${flFormat(s.x,2)} m、t = ${flFormat(m.time,2)} s 处。固定测点仍在 x₀ = ${flFormat(m.x0,1)} m。`);
 document.querySelectorAll('[data-material-preset]').forEach(b=>{const preset=materialPresets[b.dataset.materialPreset];b.setAttribute('aria-pressed',String(['u','c','source'].every(k=>Math.abs(m[k]-preset[k])<1e-9)));});
 flEl('material-play').textContent=materialPlaying?'Ⅱ 暂停':m.time>=6?'↺ 重播':'▶ 播放';flEl('material-play').setAttribute('aria-pressed',String(materialPlaying));
 let insight;
 if(Math.abs(m.u-m.c)<1e-9&&Math.abs(m.source)<1e-9)insight='粒子与温度波同速，沿轨迹的相位不变。局部项与对流项恰好抵消，粒子经历的温度不变；固定测点仍可能看到温度随波动变化。';
 else if(Math.abs(m.c)<1e-9&&Math.abs(m.source)<1e-9)insight='温度场本身不随时间改变，所以局部项为 0。粒子穿过不同温度区域，仍会经历温度变化；这正是对流项。';
 else if(Math.abs(m.u)<1e-9)insight='粒子停在起点，对流项为 0。随体粒子与固定测点重合，两者的温度历史相同，随体导数等于局部时间导数。';
 else insight=`沿粒子轨迹，温度变化率是 ${flFormat(s.total,3)} °C/s。固定测点此刻的变化率为 ${flFormat(s.fixedLocal,3)} °C/s；它与公式的局部项不一定相同，因为取值位置不同。`;
 flText('material-insight',insight+' 橙色短线表示随体温度曲线在当前时刻的切线。');
}
function pauseMaterial(){materialPlaying=false;cancelAnimationFrame(materialFrame);materialFrame=0;materialLast=0;}
function changeMaterial(input={}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid material-derivative input');
 for(const key of Object.keys(input))if(!['preset','u','c','source','x0','time'].includes(key))throw Error('Unknown field '+key);
 if(input.preset!==undefined&&!Object.hasOwn(materialPresets,input.preset))throw Error('Unknown preset');
 for(const [key,min,max]of [['u',-1.5,1.5],['c',-1.5,1.5],['source',-1.5,1.5],['x0',0,9.9],['time',0,6]])if(input[key]!==undefined&&(!Number.isFinite(input[key])||input[key]<min||input[key]>max))throw Error('Out of range: '+key);
 const next=input.preset?{...materialPresets[input.preset],time:0}:{...material};
 if(['u','c','source','x0'].some(k=>input[k]!==undefined))next.time=0;
 for(const key of ['u','c','source','x0','time'])if(input[key]!==undefined)next[key]=input[key];
 pauseMaterial();material=next;renderMaterial();return materialSnapshot();
}
function materialTick(now){
 if(!materialPlaying)return;
 if(materialLast)material.time=Math.min(6,material.time+Math.min(.1,(now-materialLast)/1000));materialLast=now;
 if(material.time>=6)pauseMaterial();renderMaterial();if(materialPlaying)materialFrame=requestAnimationFrame(materialTick);
}
for(const key of ['u','c','source','x0','time'])flEl('material-'+key).addEventListener('input',e=>changeMaterial({[key]:Number(e.target.value)}));
document.querySelectorAll('[data-material-preset]').forEach(b=>b.addEventListener('click',()=>changeMaterial({preset:b.dataset.materialPreset})));
flEl('material-reset').addEventListener('click',()=>changeMaterial({preset:'static'}));
flEl('material-step').addEventListener('click',()=>changeMaterial({time:Math.min(6,material.time+.25)}));
flEl('material-play').addEventListener('click',()=>{if(materialPlaying)pauseMaterial();else{if(material.time>=6)material.time=0;materialPlaying=true;materialFrame=requestAnimationFrame(materialTick);}renderMaterial();});
const materialSVG=flEl('material-space');
materialSVG.addEventListener('pointerdown',e=>{if(!e.target.closest('[data-material-origin]'))return;e.preventDefault();pauseMaterial();materialDragging=true;materialSVG.setPointerCapture(e.pointerId);});
materialSVG.addEventListener('pointermove',e=>{if(!materialDragging)return;const chart=materialSpaceChart,pt=new DOMPoint(e.clientX,e.clientY).matrixTransform(materialSVG.getScreenCTM().inverse());changeMaterial({x0:Math.max(0,Math.min(9.9,(pt.x-chart.left)/(chart.right-chart.left)*10))});});
for(const event of ['pointerup','pointercancel','lostpointercapture'])materialSVG.addEventListener(event,()=>{materialDragging=false;});
materialSVG.addEventListener('keydown',e=>{if(!e.target.closest('[data-material-origin]')||!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();changeMaterial({x0:Math.max(0,Math.min(9.9,material.x0+(e.key==='ArrowLeft'?-.1:.1)))});materialSVG.querySelector('[data-material-origin]')?.focus({preventScroll:true});});
document.addEventListener('visibilitychange',()=>{if(document.hidden){pauseMaterial();renderMaterial();}});
new IntersectionObserver(entries=>{if(!entries[0].isIntersecting&&materialPlaying){pauseMaterial();renderMaterial();}},{threshold:0}).observe(flEl('lab-material'));
renderReconstruction();renderMaterial();
if(document.modelContext?.registerTool){
 const fieldLifecycle=new AbortController();
 const registerFieldTool=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:fieldLifecycle.signal})).catch(()=>{});}catch{}};
 registerFieldTool({name:'configure_particle_field',title:'探索离散粒子与连续场',description:'Change the visible particle-field reconstruction lesson, including samples, kernel width, query location, or normalized weights. Particle positions must remain between their current neighbors. Returns the same calculated values shown on the page.',inputSchema:{type:'object',properties:{shape:{type:'string',enum:['wave','bump','constant']},n:{type:'integer',minimum:7,maximum:31},h:{type:'number',minimum:.025,maximum:.18},query:{type:'number',minimum:0,maximum:1},normalized:{type:'boolean'},layer:{type:'string',enum:['samples','kernels','sum']},particle:{type:'object',properties:{id:{type:'integer'},x:{type:'number'},value:{type:'number'}},required:['id'],additionalProperties:false},reset:{type:'boolean'},resample:{type:'boolean'}},additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:changeReconstruction});
 registerFieldTool({name:'configure_material_derivative',title:'探索随体导数',description:'Configure the visible analytic-temperature lesson or scrub its time; pauses playback. Changing speed, heating or origin restarts time at zero unless time is supplied. Returns local, advective and material derivatives at the moving particle.',inputSchema:{type:'object',properties:{preset:{type:'string',enum:['static','follow','heating']},u:{type:'number',minimum:-1.5,maximum:1.5},c:{type:'number',minimum:-1.5,maximum:1.5},source:{type:'number',minimum:-1.5,maximum:1.5},x0:{type:'number',minimum:0,maximum:9.9},time:{type:'number',minimum:0,maximum:6}},additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:changeMaterial});
 addEventListener('pagehide',()=>{pauseMaterial();fieldLifecycle.abort();},{once:true});
}
