import './explorer.js';
const byId=id=>document.getElementById(id);
// A quiet reading indicator, with a real section link for each chapter.
const chapterLinks = [...document.querySelectorAll('.chapter-link')];
const navigation = document.querySelector('.sidebar details');
navigation.open = matchMedia('(min-width: 851px)').matches;
const sections = [...document.querySelectorAll('article > h2')];
let scheduled = false;
function updateReading() {
  const max = document.documentElement.scrollHeight - innerHeight;
  const ratio = max > 0 ? scrollY / max : 0;
  byId('reading-progress').style.transform = `scaleX(${Math.min(1, Math.max(0, ratio))})`;
  const active = [...sections].reverse().find((section) => section.getBoundingClientRect().top < 160);
  chapterLinks.forEach((link) => {
    if (link.hash === '#' + active?.id) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  });
  scheduled = false;
}
addEventListener('scroll', () => { if (!scheduled) { scheduled = true; requestAnimationFrame(updateReading); } }, { passive: true });
addEventListener('resize', () => { updateReading();  }); updateReading();

const dialog = byId('figure-dialog');
document.querySelectorAll('.figure-link').forEach((link) => link.addEventListener('click', (event) => {
  if (typeof dialog.showModal !== 'function') return;
  event.preventDefault();
  const original = link.querySelector('img');
  byId('figure-large').src = original.src; byId('figure-large').alt = original.alt;
  byId('figure-caption').textContent = original.alt;
  byId('figure-download').href = link.href;
  dialog.showModal();
}));
byId('figure-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
