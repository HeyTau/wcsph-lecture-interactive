import { cubicKernel1D, density1D, taitPressure, timeLimits } from './models.mjs';

const byId = (id) => document.getElementById(id);
const get = (id) => Number(byId(id).value);
const show = (id, value) => { byId(id).textContent = value; };
const format = (v, digits = 2) => v.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
const NS = 'http://www.w3.org/2000/svg';
function node(tag, attrs = {}, text) {
  const el = document.createElementNS(NS, tag);
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, String(value));
  if (text !== undefined) el.textContent = text;
  return el;
}
function setupChart(id, xmin, xmax, ymin, ymax, xlabel, ylabel) {
  const svg = byId(id); svg.replaceChildren();
  const width = Math.max(280, svg.clientWidth);
  svg.setAttribute('viewBox', `0 0 ${width} 320`);
  const box = { left: 48, top: 35, width: width - 64, height: 225 };
  const x = (n) => box.left + (n - xmin) / (xmax - xmin) * box.width;
  const y = (n) => box.top + box.height - (n - ymin) / (ymax - ymin) * box.height;
  for (let i = 0; i <= 4; i++) {
    const val = ymin + (ymax - ymin) * i / 4;
    svg.append(node('line', { x1: box.left, x2: box.left + box.width, y1: y(val), y2: y(val), class: 'plot-grid' }));
    svg.append(node('text', { x: box.left - 12, y: y(val) + 4, 'text-anchor': 'end', class: 'plot-label' }, Math.abs(val) < .0001 ? '0' : format(val, Math.abs(ymax) < 10 ? 1 : 0)));
  }
  for (let i = 0; i <= 4; i++) {
    const val = xmin + (xmax - xmin) * i / 4;
    svg.append(node('text', { x: x(val), y: 285, 'text-anchor': 'middle', class: 'plot-label' }, format(val, 1)));
  }
  svg.append(node('text', { x: box.left, y: 18, class: 'plot-unit' }, ylabel));
  svg.append(node('text', { x: width - 16, y: 313, 'text-anchor': 'end', class: 'plot-unit' }, xlabel));
  svg.append(node('line', { x1: box.left, x2: width - 16, y1: y(0), y2: y(0), class: 'plot-axis' }));
  return { svg, x, y, box };
}
function curve(svg, x, y, f, a, b, attrs = {}) {
  let d = '';
  for (let i = 0; i <= 160; i++) {
    const p = a + (b - a) * i / 160;
    d += `${i ? 'L' : 'M'}${x(p).toFixed(2)},${y(f(p)).toFixed(2)} `;
  }
  svg.append(node('path', { d, fill: 'none', class: 'plot-curve', ...attrs }));
}
function density() {
  const spacing = get('density-spacing'), h = get('density-h');
  show('density-spacing-value', format(spacing)); show('density-h-value', format(h));
  const positions = Array.from({ length: 9 }, (_, i) => (i - 4) * spacing);
  const rho = density1D(0, positions, h);
  show('density-result', format(rho, 3));
  const contributing = positions.filter((p) => Math.abs(p) < 2 * h).length;
  show('density-neighbors', `${contributing} 个粒子参与中心求和`);
  const { svg, x, y, box } = setupChart('density-chart', -2.4, 2.4, 0, 2.4, '位置 x / m', '线密度 ρ / (kg/m)');
  svg.append(node('rect', { x: x(-2 * h), y: box.top, width: x(2 * h) - x(-2 * h), height: box.height, class: 'support-region' }));
  curve(svg, x, y, (p) => density1D(p, positions, h), -2.4, 2.4);
  for (const [i, p] of positions.entries()) {
    svg.append(node('line', { x1: x(p), x2: x(p), y1: y(0), y2: y(0) - 9, class: 'particle-tick' }));
    svg.append(node('circle', { cx: x(p), cy: y(0), r: i === 4 ? 6 : 4.2, class: i === 4 ? 'plot-point current' : 'plot-particle' }));
  }
  svg.append(node('line', { x1: x(0), x2: x(0), y1: y(rho), y2: y(0), class: 'plot-guide' }));
  svg.append(node('circle', { cx: x(0), cy: y(rho), r: 5, class: 'plot-point current' }));
  show('density-insight', `当前中心密度为 ${format(rho, 3)} kg/m，其中自身贡献为 ${format(.2 * cubicKernel1D(0, h), 3)} kg/m。阴影表示中心粒子的核支撑域；粒子质量始终为 0.2 kg。`);
}
function eos() {
  const cs = get('eos-cs'), gamma = get('eos-gamma'), error = get('eos-error');
  show('eos-cs-value', cs); show('eos-gamma-value', gamma); show('eos-error-value', format(error, 1));
  const pressure = (e) => taitPressure(1 + e / 100, cs, gamma) / 1000;
  const linear = (e) => cs ** 2 * e / 100;
  const p = pressure(error);
  show('eos-result', format(p));
  const { svg, x, y } = setupChart('eos-chart', -5, 8, Math.min(pressure(-5), linear(-5)) * 1.15, pressure(8) * 1.15, '密度偏差 / %', '压力 p / kPa');
  curve(svg, x, y, linear, -5, 8, { class: 'plot-linear' });
  curve(svg, x, y, pressure, -5, 8);
  svg.append(node('line', { x1: x(error), x2: x(error), y1: y(p), y2: y(0), class: 'plot-guide' }));
  svg.append(node('circle', { cx: x(error), cy: y(p), r: 6, class: 'plot-point current' }));
  show('eos-insight', `ρ = ${format(1000 * (1 + error / 100), 0)} kg/m³ 时，Tait 压力为 ${format(p)} kPa，线性近似为 ${format(linear(error))} kPa。保持密度偏差不变，声速加倍会使两者压力均变为四倍。`);
}
function timestep() {
  const cs = get('step-cs'), h = get('step-h') / 1000, velocity = get('step-v'), nu = get('step-nu') * 1e-6;
  show('step-cs-value', cs); show('step-h-value', get('step-h')); show('step-v-value', format(velocity, 1)); show('step-nu-value', get('step-nu'));
  const limits = timeLimits({ cs, h, velocity, nu });
  const finite = limits.filter((v) => Number.isFinite(v.value));
  const smallest = finite.reduce((a, b) => a.value <= b.value ? a : b);
  const max = Math.max(...finite.map((v) => v.value));
  show('step-result', format(smallest.value * 1000, 3));
  show('step-count', Math.ceil(1 / smallest.value).toLocaleString('en-US') + ' 步');
  byId('step-bars').replaceChildren();
  limits.forEach((limit) => {
    const row = document.createElement('div'); row.className = 'limit-row' + (limit === smallest ? ' is-limiting' : '');
    const header = document.createElement('div'); header.className = 'limit-label';
    const name = document.createElement('span'); name.textContent = limit.label + (limit === smallest ? ' · 当前限制' : '');
    const val = document.createElement('strong'); val.textContent = Number.isFinite(limit.value) ? format(limit.value * 1000, 3) + ' ms' : '未启用';
    header.append(name, val);
    const track = document.createElement('div'); track.className = 'limit-track';
    const bar = document.createElement('span'); bar.style.width = Number.isFinite(limit.value) ? Math.max(1, limit.value / max * 100) + '%' : '0%';
    track.append(bar); row.append(header, track); byId('step-bars').append(row);
  });
  show('step-insight', `当前由「${smallest.label}」给出最小上限。条形越短，限制越严格；未启用的黏性项不参与最小值比较。这是时间步尺度估计，不能替代具体离散方法的稳定性验证。`);
}

const runners = { density, eos, timestep };
for (const [name, run] of Object.entries(runners)) {
  const panel = document.querySelector(`[data-lab="${name}"]`);
  panel.querySelectorAll('input').forEach((input) => input.addEventListener('input', run));
  panel.querySelector('[data-reset]').addEventListener('click', () => {
    panel.querySelectorAll('input').forEach((input) => { input.value = input.defaultValue; }); run();
  });
  run();
}

// A quiet reading indicator, with a real section link for each chapter.
const chapterLinks = [...document.querySelectorAll('.chapter-link')];
const navigation = document.querySelector('.sidebar details');
navigation.open = matchMedia('(min-width: 851px)').matches;
const sections = [...document.querySelectorAll('article > h2')];
let scheduled = false;
function updateReading() {
  const max = document.documentElement.scrollHeight - innerHeight;
  const ratio = max > 0 ? scrollY / max : 0;
  byId('reading-progress').style.transform = `scaleX(${Math.min(1, Math.max(0, ratio))})`;
  const active = [...sections].reverse().find((section) => section.getBoundingClientRect().top < 160);
  chapterLinks.forEach((link) => {
    if (link.hash === '#' + active?.id) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  });
  scheduled = false;
}
addEventListener('scroll', () => { if (!scheduled) { scheduled = true; requestAnimationFrame(updateReading); } }, { passive: true });
addEventListener('resize', () => { updateReading(); density(); eos(); }); updateReading();

const dialog = byId('figure-dialog');
document.querySelectorAll('.figure-link').forEach((link) => link.addEventListener('click', (event) => {
  if (typeof dialog.showModal !== 'function') return;
  event.preventDefault();
  const original = link.querySelector('img');
  byId('figure-large').src = original.src; byId('figure-large').alt = original.alt;
  byId('figure-caption').textContent = original.alt;
  byId('figure-download').href = link.href;
  dialog.showModal();
}));
byId('figure-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });

// Optional, page-scoped access to the same visible experiment controls.
if (document.modelContext?.registerTool) {
  const lifecycle = new AbortController();
  const controlGroups = {
    density: { spacing: 'density-spacing', h: 'density-h' },
    eos: { cs: 'eos-cs', gamma: 'eos-gamma', densityErrorPercent: 'eos-error' },
    timestep: { cs: 'step-cs', hMillimeters: 'step-h', velocity: 'step-v', viscosityMm2PerS: 'step-nu' },
  };
  const outputIds = { density: 'density-result', eos: 'eos-result', timestep: 'step-result' };
  const units = { density: 'kg/m', eos: 'kPa', timestep: 'ms' };
  try {
    Promise.resolve(document.modelContext.registerTool({
      name: 'configure_wcsph_experiment',
      title: '调整 WCSPH 实验',
      description: 'Update one visible teaching experiment with validated parameters. Does not upload data or change the lecture.',
      inputSchema: { type: 'object', properties: { experiment: { type: 'string', enum: ['density', 'eos', 'timestep'] }, values: { type: 'object', additionalProperties: { type: 'number' } } }, required: ['experiment', 'values'], additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input) {
        if (!input || typeof input !== 'object' || !Object.hasOwn(controlGroups, input.experiment) || !input.values || typeof input.values !== 'object' || Array.isArray(input.values)) throw new Error('Invalid experiment input');
        const group = controlGroups[input.experiment];
        const entries = Object.entries(input.values);
        for (const [name, value] of entries) {
          if (!Object.hasOwn(group, name)) throw new Error(`Unknown parameter: ${name}`);
          const field = byId(group[name]);
          if (typeof value !== 'number' || !Number.isFinite(value) || value < Number(field.min) || value > Number(field.max)) throw new Error(`Parameter out of range: ${name}`);
        }
        for (const [name, value] of entries) byId(group[name]).value = value;
        runners[input.experiment]();
        return { experiment: input.experiment, parameters: Object.fromEntries(Object.entries(group).map(([name, id]) => [name, get(id)])), result: byId(outputIds[input.experiment]).textContent, unit: units[input.experiment] };
      },
    }, { signal: lifecycle.signal })).catch(() => {});
  } catch { /* Reading and the experiments work without this optional browser API. */ }
  addEventListener('pagehide', () => lifecycle.abort(), { once: true });
}
