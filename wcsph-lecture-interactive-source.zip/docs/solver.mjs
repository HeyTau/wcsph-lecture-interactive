// A planar SPH slice of unit thickness (1 m); all particles have the same mass.
export const RHO0 = 1000, SPACING = .075, DEFAULT_H = .09375;
export function kernel2D(r, h) {
  const q = Math.abs(r) / h;
  if (q >= 2) return 0;
  return 10 / (7 * Math.PI * h * h) * (q < 1 ? 1 - 1.5*q*q + .75*q*q*q : .25*(2-q)**3);
}
export function gradient2D(dx, dy, h) {
  const r = Math.hypot(dx, dy), q = r/h;
  if (r < 1e-12 || q >= 2) return [0,0];
  const k = 10/(7*Math.PI*h*h*h) * (q < 1 ? -3*q + 2.25*q*q : -.75*(2-q)**2) / r;
  return [k*dx,k*dy];
}
const calibration = Array.from({length:121}, (_,i) => kernel2D(Math.hypot((i%11-5)*SPACING,(Math.floor(i/11)-5)*SPACING),DEFAULT_H)).reduce((a,b)=>a+b,0);
export const MASS = RHO0/calibration;
export function makeParticles(scene='compressed') {
  return Array.from({length:121},(_,id)=>{
    let x = (id%11-5)*SPACING, y = (Math.floor(id/11)-5)*SPACING;
    if(scene==='compressed') { x*=.96; y*=.96; }
    if(scene==='disturbed' && Math.hypot(x,y)<.24) { x+=.032*Math.cos(y*8); y+=.016*Math.cos(x*9); }
    return {id,x:x+.5,y:y+.5,vx:0,vy:0};
  });
}
export function compute(particles,{h=DEFAULT_H,cs=20,gamma=7,nu=0}={}) {
  const rho = particles.map(a=>particles.reduce((sum,b)=>sum+MASS*kernel2D(Math.hypot(a.x-b.x,a.y-b.y),h),0));
  const rawPressure = rho.map(r=>RHO0*cs*cs/gamma*((r/RHO0)**gamma-1));
  const pressure = rawPressure.map(p=>Math.max(0,p));
  const acceleration = particles.map(()=>({x:0,y:0}));
  for(let i=0;i<particles.length;i++) for(let j=i+1;j<particles.length;j++) {
    const a=particles[i],b=particles[j],dx=a.x-b.x,dy=a.y-b.y;
    const [gx,gy]=gradient2D(dx,dy,h);
    if(!gx&&!gy) continue;
    const coeff=-MASS*(pressure[i]/rho[i]**2+pressure[j]/rho[j]**2);
    let fx=coeff*gx,fy=coeff*gy;
    // Symmetric physical-viscosity discretization; r dot grad(W) <= 0.
    if(nu>0) {
      const visc=2*nu*MASS/(rho[i]*rho[j])*RHO0*(dx*gx+dy*gy)/(dx*dx+dy*dy+.01*h*h);
      fx+=visc*(a.vx-b.vx); fy+=visc*(a.vy-b.vy);
    }
    acceleration[i].x+=fx; acceleration[i].y+=fy;
    acceleration[j].x-=fx; acceleration[j].y-=fy;
  }
  const speed=Math.max(...particles.map(p=>Math.hypot(p.vx,p.vy)));
  const maxA=Math.max(...acceleration.map(a=>Math.hypot(a.x,a.y)));
  const soundSpeed=Math.max(cs,...rho.map(r=>cs*(r/RHO0)**((gamma-1)/2)));
  const limits=[{name:'声学传播',value:.2*h/(soundSpeed+speed)},{name:'加速度',value:maxA>1e-10?.2*Math.sqrt(h/maxA):Infinity},{name:'黏性扩散',value:nu>0?.125*h*h/nu:Infinity}];
  const limiting=limits.reduce((a,b)=>a.value<=b.value?a:b);
  return {rho,rawPressure,pressure,acceleration,limits,dt:limiting.value,limiting:limiting.name,soundSpeed};
}
export function contributions(particles,selected,h) {
  const a=particles[selected];
  return particles.map((b,id)=>{const r=Math.hypot(a.x-b.x,a.y-b.y); return {id,r,weight:kernel2D(r,h),value:MASS*kernel2D(r,h)};}).filter(v=>v.r<2*h).sort((a,b)=>b.value-a.value);
}
export function advance(particles,params,fields=compute(particles,params)) {
  const dt=fields.dt;
  const next=particles.map((p,i)=>{
    let vx=p.vx+dt*fields.acceleration[i].x,vy=p.vy+dt*fields.acceleration[i].y;
    let x=p.x+dt*vx,y=p.y+dt*vy;
    // Simple inelastic collision with a box; no boundary-density compensation.
    if(x<.025||x>.975) {x=Math.max(.025,Math.min(.975,x));vx*=-.25;}
    if(y<.025||y>.975) {y=Math.max(.025,Math.min(.975,y));vy*=-.25;}
    return {...p,x,y,vx,vy};
  });
  return {particles:next,dt};
}
