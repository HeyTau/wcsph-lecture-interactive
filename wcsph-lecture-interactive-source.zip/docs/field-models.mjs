export const FIELD_LENGTH=10,FIELD_AMPLITUDE=8,FIELD_K=2*Math.PI/FIELD_LENGTH;
export function wrapUnit(x,period=1){return ((x%period)+period)%period;}
export function referenceField(x,shape='wave'){
  x=wrapUnit(x);
  if(shape==='constant')return 1;
  if(shape==='bump')return .3+1.35*Math.exp(-22*(1-Math.cos(2*Math.PI*(x-.5))));
  return 1+.55*Math.sin(2*Math.PI*x)+.15*Math.cos(4*Math.PI*x);
}
export function fieldKernel(r,h){
  const q=Math.abs(r)/h;
  return q>=2?0:2/(3*h)*(q<1?1-1.5*q*q+.75*q*q*q:.25*(2-q)**3);
}
export function makeSamples(n=15,shape='wave'){
  return Array.from({length:n},(_,id)=>{const x=(id+.5)/n;return {id,x,value:referenceField(x,shape)};});
}
export function sampleVolumes(samples){
  return samples.map((p,i)=>{
    const left=i===0?samples.at(-1).x-1:samples[i-1].x;
    const right=i===samples.length-1?samples[0].x+1:samples[i+1].x;
    return (right-left)/2;
  });
}
export function reconstructField(samples,x,h,normalized=false){
  const volumes=sampleVolumes(samples);
  const terms=samples.map((p,i)=>{
    const distance=Math.abs(wrapUnit(x-p.x+.5)-.5),kernel=fieldKernel(distance,h),weight=volumes[i]*kernel;
    return {id:p.id,distance,kernel,volume:volumes[i],weight,sample:p.value,raw:p.value*weight};
  });
  const partition=terms.reduce((s,t)=>s+t.weight,0),raw=terms.reduce((s,t)=>s+t.raw,0);
  const supported=partition>1e-12;
  const value=normalized?(supported?raw/partition:null):raw;
  return {value,raw,partition,supported,terms:terms.map(t=>({...t,contribution:normalized?(supported?t.raw/partition:null):t.raw}))};
}
export function temperatureField(x,t,{c=0,source=0}={}){
  return 20+FIELD_AMPLITUDE*Math.sin(FIELD_K*(x-c*t))+source*t;
}
export function materialState({u=1,c=0,source=0,x0=1.2,time=0}={}){
  const unwrappedX=x0+u*time,x=wrapUnit(unwrappedX,FIELD_LENGTH);
  const gradient=FIELD_AMPLITUDE*FIELD_K*Math.cos(FIELD_K*(unwrappedX-c*time));
  const local=source-c*gradient,advection=u*gradient,total=local+advection;
  const fixedLocal=source-c*FIELD_AMPLITUDE*FIELD_K*Math.cos(FIELD_K*(x0-c*time));
  return {x,unwrappedX,temperature:temperatureField(unwrappedX,time,{c,source}),fixedTemperature:temperatureField(x0,time,{c,source}),gradient,local,advection,total,fixedLocal};
}
