# WCSPH Explainer

基于原 WCSPH 讲义的独立交互阅读版。粒子位置、核权重、密度、压力与显式推进共用同一套模拟状态。

- 点击五个计算阶段，在总览与局部计算之间切换。
- 拖动粒子；点击选中粒子，用方向键微调；也可以输入粒子编号。
- 点选贡献条或贡献项，追踪对应的邻居。
- 选择均匀、压缩、扰动三种初始排列，播放或单步推进。
- 调整平滑长度、声速、Tait 指数与黏度。
- 阅读 9 章原讲义、38 个编号公式、7 张矢量插图。

## 开发与发布

使用 Node.js 22 或更新版本。执行 npm ci，然后 npm run build、npm run check、npm run standalone。npm run preview 提供本地预览。

lecture.md 是未改写的用户原稿；src/explorer.mjs 定义界面，src/explorer.js 管理共享状态和交互，src/solver.mjs 实现数值模型。src/styles.css 与 src/explorer.css 定义阅读及演示样式。旧的三个独立实验源文件保留用于版本参考，新页面不加载它们。

docs/ 是多文件网页。构建生成的 ../发布包/index.html 包含公式、字体、插图和所有交互代码，可离线打开。GitHub Pages 使用这个独立 HTML，仓库内的源码 ZIP 可完整解压编辑。

## 模型

121 个等质量粒子，二维单位厚度切片。二维 cubic spline 核的归一化系数为 10/(7πh²)，支撑半径 2h。粒子质量用默认均匀点阵的中心密度标定为 1000 kg/m³；改变参数或位置不重新标定质量。

密度求和包含自身项；Tait 压力截断为非负；对称压力力成对更新。显式演示关闭重力与表面张力，允许启用动量守恒、耗散的对称黏性离散（梯度形式，非正文三维专用 viscosity kernel）。边缘不补偿缺失的邻域，外框用简单非弹性碰撞。

时间步为声学、加速度与已启用黏性条件的最小值，声学项使用当前 Tait 声速上界。半隐式 Euler：先更新全部速度，再更新全部位置。播放每帧执行一次真实时间步；不把帧率当作物理时间。

## Reference

[1] 用户原讲义 lecture.md 及其参考文献。

[2] Wang et al. CNN Explainer: Learning Convolutional Neural Networks with Interactive Visualization. TVCG, 2020. https://github.com/poloclub/cnn-explainer — 交互组织参考；未复用其代码或图像。

[3] Interactive Computer Graphics, Physics Simulation in Visual Computing. https://interactivecomputergraphics.github.io/physics-simulation/examples/iisph.html — 对称压力离散。

[4] SPlisHSPlasH CubicKernel2D. https://splishsplash.readthedocs.io/en/2.12.0/api/class_s_p_h_1_1_cubic_kernel2_d.html

## 新增：连续场与随体导数

第 1.3 节后嵌入离散采样重建组件：可拖动粒子的位置与场值、选择查询位置、切换采样/核贡献/重建阶段、修改采样数量与核宽，并比较原始求和和 Shepard 归一化。使用一维长度 1 m 的周期区间；权重体积是一维 Voronoi 区间长度。未归一化时空邻域求和为零，归一化时空邻域未定义。

第 2.1 节后嵌入随体导数组件：比较固定测点与随体粒子的温度历史；提供静态场穿行、与波同速、原地升温三个示例。解析温度 T(x,t)=20+8sin[2π(x-ct)/10]+qt，轨迹 x(t)=x0+ut。局部项与对流项都在当前粒子位置计算，固定测点变化率单独区分。时间、速度、起点和升温率均可调整，支持播放与单步。

实现位于 src/field-models.mjs、src/field-lessons.mjs、src/field-lessons.js 和 src/field-lessons.css。scripts/check-fields.mjs 验证周期权重、核归一化、常数再现、无邻居状态与解析链式法则。
